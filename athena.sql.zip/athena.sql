-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2014 at 09:54 PM
-- Server version: 5.5.34-MariaDB
-- PHP Version: 5.5.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `athena`
--

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8_unicode_ci NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_b7b81f0c` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('0485m0v94os29q48uk6u0nfz7ul5drs9', 'NjJlZGUwNDA3ZTcyNWE0MmY2ZWNjZDFlMjRkYWZiNjVhZGU1YWM0NzqAAn1xAVUHdXNlcl9pZHECigEVcy4=', '2014-02-11 14:28:42'),
('20msbagrebmlxxtes2k9ty3td0cjjvlh', 'NmRkZjNkOGQ3N2Y2NWI0NjdmYThlYTk2OTcxZDU1MDVjNGI0YmNkNDqAAn1xAVUHdXNlcl9pZHECigEOcy4=', '2014-02-07 22:55:26'),
('3pnpr8u2qtqxbnxzo0whf49q4lqwgv7d', 'MWI5MjIwODA0YTNjY2IwMjdjYTZkMjFmN2IwMTYzNTc1MjVlMmRlYzqAAn1xAVUHdXNlcl9pZHECigEocy4=', '2014-02-12 11:26:03'),
('4710d4gajjvux58hprveuqvp03les9t0', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-07 19:23:42'),
('7c2ytkro16id5cxwfh1yz8r9ns5vnbza', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-13 08:50:04'),
('857xiqnyk25e27mma51ggyxr181yivup', 'NGVhMjE1NzJlNTc4YmY3MzQwZGJlZTVkZmE2YTU1NjFiZDhmMWY3NzqAAn1xAVUHdXNlcl9pZHECigEbcy4=', '2014-02-11 23:31:30'),
('8sp5kt4gsy8ir45j233jd5gkg7njn7vq', 'NmIwODUxYWViNDkyNDNiZjFlYzFkNGM5MTFhZThmMGRlZmFiZGNhNTqAAn1xAVUHdXNlcl9pZHECigEacy4=', '2014-02-11 22:59:20'),
('g277mutve5o3sa9b51lg7khpnsxb22ag', 'ZTNkOTY3ZDUzZDc1YTUyMTg2Yzk3YzhiNzE4ZjAzZWU1NWU3NDgwYjqAAn1xAVUHdXNlcl9pZHECigEkcy4=', '2014-02-12 09:28:19'),
('ht9s8f0pafzwlfvs1ws2zya3r1gncipy', 'YWY0ZTQ4MGZkYzAwZjJiNjAzMmNmZjQwYTBmYTZkOWU4NDY4ZjUxYTqAAn1xAVUHdXNlcl9pZHECigEScy4=', '2014-02-10 12:14:55'),
('i1294umj4q8xrr9hn44z9gle56by0uba', 'NDM5ZmFkMGZhODFmZWE2MmUyNzg2MjFiZjRjODkwNTUyZjRjNjRiYjqAAn1xAVUHdXNlcl9pZHECigEZcy4=', '2014-02-11 22:59:19'),
('j9uh3nrw2nt84amutjwx7rpg7jyuzk4u', 'ZmQ2NGFlMDU2MjZmZGNlZGY2NzU3NmUyM2QwY2JiYzMxZGNiNTZiMzqAAn1xAVUHdXNlcl9pZHECigEPcy4=', '2014-02-08 08:34:29'),
('jfvm5uypvnt0hie48ll53rq4e7hve63p', 'MDJkMDA3YTIwZjA5M2I1Yzc0NGMzNGUzMTRkODNhMjVjMDVlYTk4NjqAAn1xAVUHdXNlcl9pZHECigEecy4=', '2014-02-12 00:03:42'),
('k8ezmpbk4d4kmgidt48zspj30o6x50b9', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-12 00:01:55'),
('kff47u66pmxrouutsm93btvon4b5uoh6', 'NjU4N2UzMTY4MThjOGFhYWQ0NThhOTAwYTM2ZmU5YWM2MjJiMmE2YTqAAn1xAVUHdXNlcl9pZHECigEncy4=', '2014-02-12 11:24:47'),
('nbt6iva1uae0m0uje9dzyhpoms66bzmi', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-13 08:49:36'),
('nky6uafjjlui6v127v88i6ob0qeubf07', 'NTY1Nzc5ZGNhODQxN2IzYjk1NjE1N2E2NWJkMDA4NWQ4OWFjMmE3ZDqAAn1xAVUHdXNlcl9pZHECigErcy4=', '2014-02-12 12:25:34'),
('ns98z8vi0rzv7k7616ce6ndzoadjehm0', 'OWY0YjI5ZDdiMDhhODU0NGVmYzY3ODM0NGE1NmU5ZmIwYWFjMDIyNjqAAn1xAVUHdXNlcl9pZHECigEIcy4=', '2014-02-13 08:54:07'),
('p1tvk91qfnovmy0mwq4ge8xm02igadzq', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-11 12:44:17'),
('q4vcg0h86dhhor02yo33jso87gus3cmb', 'ZWIyZDNlOWY5MGJkODA5YTE4NGVlOTZiZjJmZTlkNDI2OGMxMWYzNjqAAn1xAVUHdXNlcl9pZHECigEDcy4=', '2014-02-13 08:52:21'),
('rvphj8vwsdm3ypsa7gu1zxsrmjhj684l', 'ZmRiY2M4YzdmMTAzOWIzMTVkOTNhYjkyMDc2YTkzOTYzMTMzMTFhZTqAAn1xAVUHdXNlcl9pZHECigEvcy4=', '2014-02-13 10:50:03'),
('sfx7f4q6n788s92ujjin0h8lw0998ewz', 'NzUxMzA0MzM0ODNmMjBiYTVkMTgwNzI1NjkzM2Y1MjNiOGE1ZWRhZjqAAn1xAVUHdXNlcl9pZHECigEucy4=', '2014-02-13 02:31:47'),
('xisrgra6kpp36p2etz79nklvr5nrq7iu', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-07 17:36:47'),
('xpxwtotl947n7d8b4nu3ra8h2soqfsom', 'Y2M1MDNiMDYwMGZlMmI5MDEzOThhOGVmOTE4OGU0ZWJmNTA4OTQ2MDqAAn1xAVUHdXNlcl9pZHECigEEcy4=', '2014-02-11 13:59:09'),
('yzmcibl3ei1x30g9rctk28igiz818qmo', 'ZTU3OWI1MWVkODEwMmI3MmM1ZmE0MzRmZDgwZDVmMGVjZDVkZGJiZDqAAn1xAS4=', '2014-02-08 22:35:27');

-- --------------------------------------------------------

--
-- Table structure for table `rteacher_exam`
--

CREATE TABLE IF NOT EXISTS `rteacher_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rteacher_exam_add748bb` (`test_id`),
  KEY `rteacher_exam_5f412f9a` (`group_id`),
  KEY `rteacher_exam_cb902d83` (`owner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `rteacher_exam`
--

INSERT INTO `rteacher_exam` (`id`, `test_id`, `group_id`, `name`, `created_on`, `owner_id`) VALUES
(3, 1, 1, 'DEMO EGZAMIN', '2014-01-28 10:25:42', 2),
(4, 1, 2, 'TSW 2013/2014', '2014-01-29 12:26:45', 3);

-- --------------------------------------------------------

--
-- Table structure for table `rteacher_group`
--

CREATE TABLE IF NOT EXISTS `rteacher_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `is_archival` tinyint(1) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rteacher_group_c12e9d48` (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `rteacher_group`
--

INSERT INTO `rteacher_group` (`id`, `teacher_id`, `name`, `description`, `is_archival`, `created_on`) VALUES
(1, 2, 'DEMO', 'Grupa tymczasowych kont Demo. Konta są kasowane po wylogowaniu się użytkownika', 1, '2014-01-01 00:00:00'),
(2, 3, 'Piszący z cieniami', '---', 0, '2014-01-24 11:44:08');

-- --------------------------------------------------------

--
-- Table structure for table `rteacher_group_students`
--

CREATE TABLE IF NOT EXISTS `rteacher_group_students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`user_id`),
  KEY `rteacher_group_students_5f412f9a` (`group_id`),
  KEY `rteacher_group_students_6340c63c` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=45 ;

--
-- Dumping data for table `rteacher_group_students`
--

INSERT INTO `rteacher_group_students` (`id`, `group_id`, `user_id`) VALUES
(11, 1, 14),
(12, 1, 15),
(15, 1, 18),
(18, 1, 21),
(22, 1, 25),
(23, 1, 26),
(24, 1, 27),
(27, 1, 30),
(33, 1, 36),
(36, 1, 39),
(37, 1, 40),
(40, 1, 43),
(43, 1, 46),
(44, 1, 47),
(1, 2, 4),
(5, 2, 8),
(17, 2, 20);

-- --------------------------------------------------------

--
-- Table structure for table `rteacher_joinrequest`
--

CREATE TABLE IF NOT EXISTS `rteacher_joinrequest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `reason` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rteacher_joinrequest_94741166` (`student_id`),
  KEY `rteacher_joinrequest_5f412f9a` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `rteacher_term`
--

CREATE TABLE IF NOT EXISTS `rteacher_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `term_time` datetime NOT NULL,
  `is_closed` tinyint(1) NOT NULL,
  `is_progressing` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rteacher_term_57ed41d1` (`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `rteacher_term`
--

INSERT INTO `rteacher_term` (`id`, `exam_id`, `name`, `term_time`, `is_closed`, `is_progressing`) VALUES
(5, 3, 'DEMO TERMIN', '2014-01-28 10:25:42', 0, 1),
(7, 4, 'Pre-zerówka', '2014-01-29 14:31:00', 1, 0),
(8, 4, 'Post-zerówka', '2014-01-31 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tests_answer`
--

CREATE TABLE IF NOT EXISTS `tests_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `is_right` tinyint(1) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_answer_25110688` (`question_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=315 ;

--
-- Dumping data for table `tests_answer`
--

INSERT INTO `tests_answer` (`id`, `content`, `is_right`, `question_id`) VALUES
(1, '<!DOCTYPE HTML>', 1, 1),
(2, '<!doctype html>', 1, 1),
(3, '<!DOCTYPE HTML PUBLIC "-//W4C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">', 0, 1),
(4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 2.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml2.dtd">', 0, 1),
(5, '<html>', 1, 2),
(6, '<title>', 1, 2),
(7, '<div>', 0, 2),
(8, '<p>', 0, 2),
(9, '<meta>', 0, 3),
(10, '<h7>', 1, 3),
(11, '<font>', 1, 3),
(12, '<em>', 0, 3),
(13, '<style>', 1, 4),
(14, '<h8>', 0, 4),
(15, '<font>', 0, 4),
(16, '<abbr>', 1, 4),
(17, '<tr>', 0, 5),
(18, '<td>', 1, 5),
(19, '<th>', 1, 5),
(20, '<table>', 0, 5),
(21, '<style>', 0, 6),
(22, '<script>', 1, 6),
(23, '<div>', 1, 6),
(24, '<meta>', 0, 6),
(25, '<meta>', 1, 7),
(26, '<div>', 0, 7),
(27, '<style>', 1, 7),
(28, '<script>', 1, 7),
(29, 'Nagłówek HTTP Content-Type', 1, 8),
(30, '<meta http-equiv="Content-Type" ...', 1, 8),
(31, 'BOM dokumentu', 0, 8),
(32, 'Deklaracja <html encoding="...', 0, 8),
(33, 'JSON.parse()', 1, 10),
(34, 'eval()', 1, 10),
(35, 'json_decode()', 0, 10),
(36, 'decode from json', 0, 10),
(37, '<a href="http://www.prz.edu.pl" target="blank">Link</a>', 1, 12),
(38, '<a target="_blank" href="http://www.prz.edu.pl">Link</a>', 1, 12),
(39, '<a id="_self" href="http://www.prz.edu.pl">Link</a>', 0, 12),
(40, '<a href="http://www.prz.edu.pl" id="self">Link</a>', 0, 12),
(41, '<a href="myID">Tekst odsyłacza</a><a id="#myID">Miejsce odesłania</a>', 0, 13),
(42, '<a href="#myID">Tekst odsyłacza</a><a id="#myID">Miejsce odesłania</a>', 0, 13),
(43, '<a href="#myID">Tekst odsyłacza</a><a id="myID">Miejsce odesłania</a>', 1, 13),
(44, '<a href="myID">Tekst odsyłacza</a><a id="myID">Miejsce odesłania</a>', 0, 13),
(45, 'window.alert("Alert window");', 0, 11),
(46, 'document.alert("Alert window");', 0, 11),
(47, 'alert("Alert window");', 1, 11),
(48, 'self.alert("Alert window");', 1, 11),
(49, 'document.getElementById(''myImg'').innerHTML = "300";', 0, 15),
(50, 'document.getElementsByTagName(''myImg'').height = "300";', 0, 15),
(51, 'document.getElementById(''myImg'').height = "300";', 1, 15),
(52, 'document.getElementsByTagName(''myImg'').src = "300";', 0, 15),
(53, 'document.getElementById(''myTable'').rows[1].cells[0].src = "newValue";', 0, 16),
(54, 'myTable.rows[1].cells[0].innerHTML = "newValue";', 0, 16),
(55, 'myTable.rows[1].cells[0].src = "newValue";', 0, 16),
(56, 'document.getElementById(''myTable'').rows[1].cells[0].innerHTML = "newValue";', 1, 16),
(57, 'document.getElementById(''myImg'').innerHTML = "image.gif";', 0, 17),
(58, 'document.getElementsByTagName(''myImg'').innerHTML = "image.gif";', 0, 17),
(59, 'document.getElementById(''myImg'').src = "image.gif";', 1, 17),
(60, 'document.getElementsByTagName(''myImg'').src = "image.gif";', 0, 17),
(61, '<nazwisko%>abc</nazwisko%>', 0, 19),
(62, '<nazwisko.>abc</nazwisko.>', 1, 19),
(63, '<5nazwisko>abc</5nazwisko>', 0, 19),
(64, '<nazwisko:nowak>abc</nazwisko:nowak>', 0, 19),
(65, '<myTag:myNs>Zawartość</myTag:myNs>', 0, 20),
(66, '<myNs:myTag>Zawartość</myNs:myTag>', 1, 20),
(67, '<xmlns:myTag>Zawartość</xmlns:myTag>', 0, 20),
(68, '<myNs:xmlns>Zawartość</myNs:xmlns>', 0, 20),
(69, '<xml:CDATA[ dowolne znaki]>', 0, 21),
(70, '<PCDATA> dowolne znaki </PCDATA>', 0, 21),
(71, '<![CDATA[ dowolne znaki ]]>', 1, 21),
(72, '<CDATA> dowolne znaki </CDATA>', 0, 21),
(73, 'zawiera tylko dane znakowe', 1, 22),
(74, 'jest elementem pustym <Tag_name />', 0, 22),
(75, 'zawiera dowolne dane, także binarne', 0, 22),
(76, 'jest elementem o nazwie Tag_name zawierającym sekcję danych CDATA', 0, 22),
(77, 'Element główny w pliku XML musi nazywać się book', 1, 23),
(78, 'Znacznik books musi wystąpić przynajmniej jeden raz, ale może wystąpić wiele razy', 1, 23),
(79, 'Element główny o nazwie books musi mieć atrybut o nazwie book', 0, 23),
(80, 'Atrybut o nazwie book musi mieć wartość "+"', 0, 23),
(81, 'Określa reguły przekształcania węzła głównego dokumentu XML', 1, 24),
(82, 'Może wystąpić w dokumencie XSL tylko raz ponieważ definiuje element główny', 1, 24),
(83, 'W przestrzeni xsl nie ma takiego znacznika', 0, 24),
(84, 'Liczba wystąpień tego elementu w dokumencie XSL jest nieograniczona', 0, 24),
(85, '<xsd:element name="Name"><xsd:complexType> ... </xsd:complexType></xsd:element>', 1, 25),
(86, '<xsd:element name="Name"><xsd:simpleType> ... </xsd:simpleType></xsd:element>', 0, 25),
(87, '<xsd:element name="Name"><xsd:primitiveType> ... </xsd:primitiveType></xsd:element>', 0, 25),
(88, '<xsd:element name="Name"><simpleType> ... </simpleType></xsd:element>', 0, 25),
(89, '<xsl:attribute name="attr_name">attr_value</xsl:attribute>', 1, 26),
(90, '<xsl:value-of select="@attr_name" />', 0, 26),
(91, '<xsl:variable name="attr_name">attr_value</xsl:variable>', 0, 26),
(92, 'Nie można ustalać wartości atrybutu', 0, 26),
(93, '<xsl:value-of select="$nazwa_zmiennej"/>', 1, 27),
(94, '<xsl:value-of select="@nazwa_zmiennej"/>', 0, 27),
(95, '<xsl:attribute select="$nazwa_zmiennej"/>', 0, 27),
(96, '<xsl:attribute select="@nazwa_zmiennej"/>', 0, 27),
(98, 'map = new GMap2(document.getElementById("myMap"));', 1, 28),
(99, 'map = new GMap2(getElementById("myMap"));', 0, 28),
(100, 'map = new GMap2(window.getElementById("myMap"));', 0, 28),
(101, 'map = new GMap2(div.getElementById("myMap"));', 0, 28),
(102, 'request.send(null);', 0, 29),
(103, 'request.open("GET", "http://domain/script.php");', 1, 29),
(104, 'request.open("POST", "http://domain/script.php");', 0, 29),
(105, 'request.send("http://domain/script.php?varl=value1&var2=value2");', 0, 29),
(106, 'Łączyć się z dowolnym zdalnym serwerem', 0, 30),
(107, 'Łączyć się z adresem URL tej samej domeny, co wywoływana strona', 1, 30),
(108, 'Łączyć się z dowolnym adresem URL', 0, 30),
(109, 'Ajax nie łączy się z żadnym serwerem', 0, 30),
(110, 'request.responseText;', 1, 31),
(111, 'request.responseXML.documentElement.firstChild.nodeValue;', 1, 31),
(112, 'document.responseText.documentElement.firstChild.nodeValue;', 0, 31),
(113, 'document.responseXML;', 0, 31),
(114, 'Aby zwiększyć szybkość realizacji żądania', 0, 32),
(115, 'Aby za każdym razem było wygenerowane nowe żądanie HTTP', 1, 32),
(116, 'Aby strona nie była wczytana z pamięci podręcznej przeglądarki (cache)', 1, 32),
(117, 'W ogóle nie stosuje się takiego rozwiązania', 0, 32),
(118, 'komunikat o błędzie (error)', 0, 33),
(119, 'komunikat o błędzie (notice)', 1, 33),
(120, '55', 0, 33),
(121, '22', 0, 33),
(122, 'Tylko do odczytu', 0, 34),
(123, 'Tylko do zapisu', 1, 34),
(124, 'Do czytania i zapisu', 0, 34),
(125, 'Dopisywania danych do pliku', 1, 34),
(126, '<?php $a = "Jan"; ?><h1><?php echo $a; ?></h1>', 1, 35),
(127, '<?php $a = "Jan"; echo $a; ?>', 1, 35),
(128, '<?php> $a = "Jan"; </?><h1><?php> echo $a; </?></h1>', 0, 35),
(129, '<?php> $a = "Jan"; echo $a; </?>', 0, 35),
(130, 'select_mysql_db()', 0, 36),
(131, 'mysql_select_db()', 1, 36),
(132, 'connect_mysql() z parametrem kluczowym database', 0, 36),
(133, 'mysql_connect() z parametrem kluczowym database', 0, 36),
(134, 'Nazwy funkcji obsługi zdarzeń w parserze SAX trzeba rejestrować', 1, 37),
(135, 'Interfejs SimpleXML jest standardem W3C', 0, 37),
(136, '$xslt->transformToDoc($xml) pozwala na przeksztalcenie pliku XML do drzewa DOM', 0, 37),
(137, 'Język PHP nie ma mechanizmów przetwarzania danych XML', 0, 37),
(138, 'xml_parser_create()', 0, 38),
(139, 'xml_set_element_handler()', 0, 38),
(140, 'xml_set_character_data_handler()', 1, 38),
(141, 'xml_parse()', 0, 38),
(142, '$dom->saveXML();', 0, 39),
(143, '$dom->save(''fileName.xml'');', 1, 39),
(144, '$dom->open(''fileName.xml'');', 0, 39),
(145, 'PHP nie umożliwia zapisu do pliku drzewa DOM', 0, 39),
(146, 'Jest standardem organizacji W3C', 0, 40),
(147, 'Obsługuje przestrzenie nazw', 1, 40),
(148, 'Umożliwia zapis do pliku XML', 1, 40),
(149, 'Nie ma takiego interfejsu w języku PHP', 0, 40),
(150, '<img src="rysunek.gif" name="rys1">', 0, 41),
(151, '<img src="rysunek.gif" name="rys1" />', 0, 41),
(152, '<img src="rysunek.gif" id="rys1">', 0, 41),
(153, '<img src="rysunek.gif" id="rys1" />', 0, 41),
(154, '<link rel="stylesheet" type="text/css" href="plik_stylow.css" />', 1, 42),
(155, '<head rel="stylesheet" type="text/css" href="plik_stylow.css" />', 0, 42),
(156, '<style rel="stylesheet" type="text/css" href="plik_stylow.css" />', 0, 42),
(157, '<link href="stylesheet" type="text/css" href="plik_stylow.css" />', 0, 42),
(191, 'a = {};', 1, 52),
(192, 'a = new object();', 0, 52),
(193, 'a = new Object();', 1, 52),
(194, 'a = new object;', 0, 52),
(195, 'Jako potomek <head>', 1, 53),
(196, 'Jako potomek <body>', 1, 53),
(197, 'Wewnątrz <script>', 1, 53),
(198, 'Jako dziecko <html>', 0, 53),
(199, '<script language="javascript" src="javascript.js"></script>', 1, 54),
(200, '<script language="javascript" href="javascript.js"></script>', 0, 54),
(201, '<script type="text/javascript" src="javascript.js"></script>', 1, 54),
(202, '<script type="text/javascript" href="javascript.js"></script>', 0, 54),
(203, 'Przy AJAX serwer może przesłać dowolną funkcję JavaScript którą eval() wykona', 1, 55),
(204, 'Nie jest zalecana do dekodowania JSON ze względów bezpieczeństwa', 1, 55),
(205, 'Funkcja ta wykonuje przekazany tekst jakby był kodem JavaScript i zwraca wartość', 1, 55),
(206, 'Nie ma takiej funkcji', 0, 55),
(207, '[]', 1, 56),
(208, 'pusty string', 0, 56),
(209, '0', 0, 56),
(210, 'null', 0, 56),
(211, '[]', 0, 57),
(212, 'NaN', 0, 57),
(213, '0', 1, 57),
(214, '{}', 0, 57),
(215, '{}', 1, 58),
(216, 'obiekt', 1, 58),
(217, '[]', 0, 58),
(218, 'NaN', 0, 58),
(219, 'NaN', 1, 59),
(220, '{}', 0, 59),
(221, '0', 0, 59),
(222, 'pusty string', 0, 59),
(223, 'NaN', 1, 60),
(224, 'pusty string', 0, 60),
(225, '"wa"', 0, 60),
(226, 'null', 0, 60),
(227, 'P3P', 1, 62),
(228, 'Platform for Privacy Preferences', 1, 62),
(229, 'Privacy Information System', 0, 62),
(230, 'PIS', 0, 62),
(231, 'SPDY', 1, 63),
(232, 'HTTP', 1, 63),
(233, 'Gopher', 0, 63),
(234, 'HTTPS', 1, 63),
(235, 'World Wide Web Consortium', 1, 64),
(236, 'W3C', 1, 64),
(237, 'Mozilla', 0, 64),
(238, 'Google', 0, 64),
(239, 'drwxrwxrwx', 0, 65),
(240, 'drwxrw-rw-', 1, 65),
(241, 'drwx-w--w-', 0, 65),
(242, 'drwx-wx-wx', 0, 65),
(243, '<html><body><head>Tekst</body></head></html>', 0, 66),
(244, '<html><head></head><body>Tekst</body></html>', 1, 66),
(245, '<html><title><body>Tekst</body></title></html>', 0, 66),
(246, '<html><body><head>Tekst</body></head></html>', 0, 66),
(247, 'HTML5', 1, 67),
(248, 'HTML 4.01 Strict', 1, 67),
(249, 'XHTML3', 0, 67),
(250, 'XHTML2', 1, 67),
(251, 'font-style: italic; color: red;', 1, 68),
(252, 'font-style: italic; font-color: red;', 0, 68),
(253, 'font-weight: italic; color: red;', 0, 68),
(254, 'font-weight: italic; font-color: red;', 0, 68),
(255, 'h1.position_left { position: absolute; left: 50px; }', 1, 69),
(256, 'h1.position_left { position: absolute; left: -50px; }', 1, 69),
(257, 'h1.position_left { position: relative; left: 50px; }', 0, 69),
(258, 'h1.position_left { position: relative; left: -50px; }', 0, 69),
(259, 'clear: both;', 1, 70),
(260, 'clear: left;', 1, 70),
(261, 'clear: right;', 0, 70),
(262, 'float: stop;', 0, 70),
(263, 'relative', 1, 71),
(264, 'absolute', 1, 71),
(265, 'static', 1, 71),
(266, 'fixed', 1, 71),
(267, 'CSS2, border-radius', 0, 72),
(268, 'CSS3, border-radius', 1, 72),
(269, 'CSS1, border-round', 0, 72),
(270, 'CSS3, border-round', 0, 72),
(271, 'red;', 1, 73),
(272, 'rgb(255, 0, 0);', 1, 73),
(273, '#00FF00;', 0, 73),
(274, 'rgba(255, 0, 0, 1);', 1, 73),
(275, 'mysql_fetch_row($res);', 1, 74),
(276, 'mysql_fetch_array($res);', 1, 74),
(277, 'mysql_fetch_data($res);', 0, 74),
(278, 'mysql_fetch_list($res);', 0, 74),
(279, 'document.getElementById(''aka'').style.color = "blue";', 1, 18),
(280, 'document.getElementByTagName(''p'').style.color = "blue";', 0, 18),
(281, 'document.getElementById(''aka'').color = "blue";', 0, 18),
(282, 'document.getElementById(''aka'').css(''color'', ''blue'');', 0, 18),
(283, 'Elementy w wyjściowym XML mają być elementami XHTML', 1, 77),
(284, 'Elementy w wyjściowym XML mają być elementami TEI', 0, 77),
(285, 'Elementy w wejściowym XML mają być elementami XHTML', 0, 77),
(286, 'Elementy w wejściowym XML mają być elementami TEI', 0, 77),
(287, '.readyState', 0, 79),
(288, '.status', 1, 79),
(289, '.statusText', 0, 79),
(290, '.code', 0, 79),
(291, 'HTML', 1, 80),
(292, 'XML', 1, 80),
(293, 'JSON', 1, 80),
(294, 'YAML', 1, 80),
(295, 'Java', 1, 81),
(296, 'C++', 1, 81),
(297, 'PHP', 1, 81),
(298, 'JavaScript', 1, 81),
(299, 'Dokument został zakodowany z BOM', 1, 82),
(300, 'Wcześniej wysłany został jakiś kod HTML', 1, 82),
(301, 'Wcześniej zostały wysłane spacje', 1, 82),
(302, 'Moduł session nie jest zainstalowany poprawnie', 0, 82),
(303, 'Linux, Apache, MySQL, PHP', 1, 83),
(304, 'Linux, Apache, MySQL, Python', 0, 83),
(305, 'Linux, Apache, MariaDB, PHP', 0, 83),
(306, 'Linux, Nginx, MySQL, PHP', 0, 83),
(307, 'JavaFX', 1, 84),
(308, 'Flash', 1, 84),
(309, 'AJAX', 1, 84),
(310, 'Silverlight', 1, 84),
(311, 'Mniejsze zużycie pamięci', 1, 85),
(312, 'Większa elastyczność dla programisty', 0, 85),
(313, 'Możliwość obsługi bardzo dużych plików XML', 1, 85),
(314, 'Mniejszy nakład pracy programisty do przetworzenia XML', 0, 85);

-- --------------------------------------------------------

--
-- Table structure for table `tests_attachment`
--

CREATE TABLE IF NOT EXISTS `tests_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `filetype` longtext COLLATE utf8_unicode_ci NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_attachment_25110688` (`question_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tests_attachment`
--

INSERT INTO `tests_attachment` (`id`, `description`, `filetype`, `question_id`) VALUES
(1, 'Załącznik', 'png', 68);

-- --------------------------------------------------------

--
-- Table structure for table `tests_category`
--

CREATE TABLE IF NOT EXISTS `tests_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `question_amount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_category_add748bb` (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tests_category`
--

INSERT INTO `tests_category` (`id`, `test_id`, `name`, `question_amount`) VALUES
(1, 1, 'HTML', 6),
(2, 1, 'JavaScript', 2),
(3, 1, 'HTML DOM', 2),
(4, 1, 'XML', 3),
(5, 1, 'XSLT', 2),
(6, 1, 'PHP', 6),
(7, 1, 'AJAX', 5),
(10, 1, 'Pytania na 5', 1),
(11, 1, 'Ogólnowojskowe', 1),
(12, 1, 'CSS', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tests_question`
--

CREATE TABLE IF NOT EXISTS `tests_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `points` double NOT NULL,
  `time` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_question_6f33f001` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=86 ;

--
-- Dumping data for table `tests_question`
--

INSERT INTO `tests_question` (`id`, `content`, `points`, `time`, `category_id`) VALUES
(1, 'Jaki jest poprawny DOCTYPE HTML5?', 1, NULL, 1),
(2, 'Jakie tagi obowiązkowo muszą pojawić się w dokumencie HTML?', 1, NULL, 1),
(3, 'Których tagów NIE definiuje HTML5?', 1, NULL, 1),
(4, 'Które tagi definiuje HTML5?', 1, NULL, 1),
(5, 'Jakie tagi generują komórkę w tabeli?', 1, NULL, 1),
(6, 'Jakie tagi można stosować wewnątrz <body>?', 1, NULL, 1),
(7, 'Jakie tagi można stosować wewnątrz <head>?', 1, NULL, 1),
(8, 'Jak można informować przeglądarkę o kodowaniu dokumentu HTML?', 1, NULL, 1),
(10, 'Jak można dekodować JSON w języku JavaScript?', 1, NULL, 2),
(11, 'Otwarcie okna dialogowego z napisem "Alert window" realizuje składnia języka JavaScript?', 1, NULL, 2),
(12, 'Który zapis jest zgodny ze składnią języka HTML i pozwala po kliknięciu na odsyłacz hipertekstowy na otwarcie strony o określonym adresie w nowym oknie?', 1, NULL, 1),
(13, 'Odsyłacz hipertekstowy z miejsca "Tekst odsyłacza" do miejsca "Miejsce odesłania" w ramach tej samej strony HTML jest realizowany za pomocą składni?', 1, NULL, 1),
(15, 'Dynamiczną zmianę wysokości obrazka o identyfikatorze id="myImg" za pomocą HTML DOM realizuje kod:', 1, NULL, 3),
(16, 'Stosując HTML DOM zmianę zawartości tekstowej pierwszej komórki w drugim wierszu tabeli HTML z id="myTable" na nową wartość newValue umożliwia składnia', 1, NULL, 3),
(17, 'Dynamiczną zmianę obrazka o identyfikatorze id="myImg" za pomocą HTML DOM realizuje kod', 1, NULL, 3),
(18, 'Dynamiczną zmianę koloru tekstu w akapicie o identyfikatorze id="aka" za pomocą HTML DOM realizuje kod:', 1, NULL, 3),
(19, 'Która nazwa znacznika jest zgodna ze składnią języka XML dla pliku bez zdefiniowanej przestrzeni nazw?', 1, NULL, 4),
(20, 'W języku XML określenie znacznika myTag z przestrzeni nazw myNs ma postać', 1, NULL, 4),
(21, 'Sekcja danych w języku XML ma strukturę', 1, NULL, 4),
(22, 'Zawartość o postaci <!ELEMENT Tag_name (#PCDATA)> w definicji typu dokumentu (DTD) deklaruje, że element o nazwie Tag_name', 1, NULL, 4),
(23, 'W zewnętrznej definicji typu dokumentu (DTD) do której odwołuje się plik XML w pierwszej linii jest zapis <!ELEMENT books (book)+>. Które poniższe stwierdzenie jest prawdziwe?', 1, NULL, 4),
(24, 'Para elementów <xsl:stylesheet ..."> ... </xsl:stylesheet> w pliku szablonu *.xsl języka XSLT', 1, NULL, 5),
(25, 'Która konstrukcja składni typu złożonego w schemacie XML Schema jest poprawna', 1, NULL, 5),
(26, 'Ustalenie wartości atrybutu o nazwie attr_name w szablonach języka XSLT ma postać', 1, NULL, 5),
(27, 'Jeśli deklaracja zmiennej w języku XSLT odbywa się za pomocą wyrażenia <xsl:variable name="nazwa_zmiennej" select="..."/> to odwołanie do tej zmiennej ma postać', 1, NULL, 5),
(28, 'W technologii AJAX dla usługi Google Maps tworzenie obiektu mapy klasy GMap2 i wstawienie go do div-a z identyfikatorem myMap odbywa się za pomocą kodu języka JavaScript', 1, NULL, 7),
(29, 'W technologii AJAX dla obiektu żądania request wysłanie do serwera żądania HTTP typu GET realizuje składnia języka JavaScript', 1, NULL, 7),
(30, 'Obiekt XMLHttpRequest w technologii Ajax może', 1, NULL, 7),
(31, 'Która struktura uaktualnienia div-a strony HTML o id="myDiv" przy żądaniu AJAX dla odpowiedzi XML jest możliwa pod względem składni', 1, NULL, 7),
(32, 'W technologii AJAX przy realizacji żądania typu GET dodaje się do końca adresu URL dodatkowy, nic nie znaczący parametr z losową wartością. W jakim celu?', 1, NULL, 7),
(33, 'Dla tablicy języka PHP zdefiniowanej jako $a=array("a"=>55, "b"=>22); polecenie echo $b[a]; wyświetli', 1, NULL, 6),
(34, 'W języku PHP funkcja fopen("myFile.txt", "a") pozwala na otwarcie pliku myFile.txt w trybie', 1, NULL, 6),
(35, 'Która struktura języka PHP jest poprawna pod względem składni', 1, NULL, 6),
(36, 'Wybór bazy danych z poziomu języka PHP umożliwia funkcja', 1, NULL, 6),
(37, 'Proszę zaznaczyć zdania prawdziwe dotyczące przetwarzania danych XML z poziomu języka PHP', 1, NULL, 6),
(38, 'Przekazanie nazwy funkcji która będzie wywoływana kiedy parser SAX czyta dane znakowe umieszczone między parą znaczników umożliwia wbudowana funkcja PHP', 1, NULL, 6),
(39, 'Zapis do pliku drzewa DOM zdefiniowanego pod zmienną $dom w języku PHP umożliwia', 1, NULL, 6),
(40, 'Interfejs SimpleXML w języku PHP', 1, NULL, 6),
(41, 'Która składnia wstawienia rysunku zgodnie ze składnią XHTML jest poprawna', 1, NULL, 1),
(42, 'Jaka jest poprawna składnia odwołania w dokumencie XHTML do zewnętrznego arkusza stylów', 1, NULL, 1),
(52, 'Jak można utworzyć instację obiektu w języku JavaScript?', 1, NULL, 2),
(53, 'Gdzie można umieścić JavaScript?', 1, NULL, 2),
(54, 'Jak odwołujemy się do zewnętrznego JavaScript?', 1, NULL, 2),
(55, 'Które z poniższych prawdziwe są w stosunku do funkcji eval() języka JavaScript?', 1, NULL, 2),
(56, 'Jaki jest wynik operacji [] + [] w JavaScript?', 1, NULL, 10),
(57, 'Jaki jest wynik operacji {} + [] w JavaScript?', 1, NULL, 10),
(58, 'Jaki jest wynik operacji [] + {} w JavaScript?', 1, NULL, 10),
(59, 'Jaki jest wynik operacji {} + {} w JavaScript?', 1, NULL, 10),
(60, 'Jaki jest wynik operacji "wat"-1 w JavaScript?', 1, NULL, 10),
(62, 'Jak nazywa się standard dzięki któremu witryna może określić przeznaczenie zbieranych informacji osobowych?', 1, NULL, 10),
(63, 'Jakie protokoły są w użyciu do transportowania hipertekstu do przeglądarki WWW?', 1, NULL, 10),
(64, 'Kto ustala standardy sieci Web?', 1, NULL, 11),
(65, 'Jak powinny być ustawione prawa dostępu do katalogu w którym umieszczone są pliki serwisu WWW?', 1, NULL, 11),
(66, 'Która forma zapisu jest zgodna ze składnią języka HTML?', 1, NULL, 1),
(67, 'Jakie są standardy (X)HTML?', 1, NULL, 11),
(68, 'Jakim zapisem CSS można uzyskać poniższy efekt?', 1, NULL, 12),
(69, 'Który zapis CSS jest poprawny przy pozycjonowaniu bezwzględnym?', 1, NULL, 12),
(70, 'Jaki zapis CSS spowoduje zatrzymanie obiektów pływających lewostronnie powyżej obiekty z tymże zapisem?', 1, NULL, 12),
(71, 'Jakie rodzaje pozycjonowania w CSS są dostępne?', 1, NULL, 12),
(72, 'Który standard CSS definiuje zaokrąglone krawędzie pudełek?', 1, NULL, 12),
(73, 'Który z poniższych sposobów określenia koloru czerwonego w CSS jest poprawny?', 1, NULL, 12),
(74, 'Który ze sposobów pobrania danych z zasobu wykonanego zapytania MySQL w PHP jest poprawny?', 1, NULL, 6),
(77, 'Co znaczy atrybut xmlns="http://www.w3.org/1999/xhtml" w elemencie <xsl:stylesheet>?', 1, NULL, 5),
(79, 'Jakie pole obiektu XMLHttpResponse zawiera liczbowy kod wykonanego żądania?', 1, NULL, 7),
(80, 'Jaki rodzaj danych odbierać można poprzez AJAX?', 1, NULL, 7),
(81, 'W jakim języku może być napisany kod który po stronie serwera obsługiwał będzie zapytania AJAX?', 1, NULL, 7),
(82, 'Co może być przyczyną błędu "Cannot send session cache limiter - headers already sent" w języku PHP?', 1, NULL, 6),
(83, 'Jaki zestaw oprogramowania oznacza najczęściej skrót LAMP?', 1, NULL, 11),
(84, 'Jakie technologie można zastosować do tworzenia RIA?', 1, NULL, 11),
(85, 'Jaką przewagę mają parsery SAX nad parserami DOM?', 1, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tests_test`
--

CREATE TABLE IF NOT EXISTS `tests_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `time` int(11) DEFAULT NULL,
  `can_go_back` tinyint(1) NOT NULL,
  `is_time_per_question` tinyint(1) NOT NULL,
  `is_multichoice` tinyint(1) NOT NULL,
  `can_review_mistakes` tinyint(1) NOT NULL,
  `is_demo` tinyint(1) NOT NULL,
  `g3_starts_at` int(11) NOT NULL,
  `g35_starts_at` int(11) NOT NULL,
  `g4_starts_at` int(11) NOT NULL,
  `g45_starts_at` int(11) NOT NULL,
  `g5_starts_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_test_cb902d83` (`owner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tests_test`
--

INSERT INTO `tests_test` (`id`, `owner_id`, `name`, `time`, `can_go_back`, `is_time_per_question`, `is_multichoice`, `can_review_mistakes`, `is_demo`, `g3_starts_at`, `g35_starts_at`, `g4_starts_at`, `g45_starts_at`, `g5_starts_at`) VALUES
(1, 3, 'Technologie sieci Web', 1200, 1, 0, 1, 1, 1, 60, 66, 76, 86, 96);

-- --------------------------------------------------------

--
-- Table structure for table `tests_testbeingwritten`
--

CREATE TABLE IF NOT EXISTS `tests_testbeingwritten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_id` int(11) NOT NULL,
  `written_by_id` int(11) NOT NULL,
  `state` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_testbeingwritten_22e62ab6` (`term_id`),
  KEY `tests_testbeingwritten_35be4010` (`written_by_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tests_testbeingwritten`
--

INSERT INTO `tests_testbeingwritten` (`id`, `term_id`, `written_by_id`, `state`) VALUES
(3, 5, 47, 'gAJjYXRoZW5hLnRlc3RzLmNvbXBvc2VyClRlc3RXcml0dGVuCnEBKYFxAn1xAyhVEGlzX3Rlc3RfZmluaXNoZWRxBIlVD3Rlc3Rfc3RhcnRlZF9vbnEFY2RhdGV0aW1lCmRhdGV0aW1lCnEGVQoH3gEeCjIXBBDqhVJxB1UPaXNfdGVzdF9zdGFydGVkcQiIVQdyYXd0ZXN0cQljYXRoZW5hLnRlc3RzLmNvbXBvc2VyClJhd1Rlc3QKcQopgXELfXEMKFUOYW5zd2Vyc192YWx1ZXNxDX1xDihjY29weV9yZWcKX3JlY29uc3RydWN0b3IKcQ9jYXRoZW5hLnRlc3RzLm1vZGVscwpRdWVzdGlvbgpxEGNfX2J1aWx0aW5fXwpvYmplY3QKcRFOh1JxEn1xEyhVBl9zdGF0ZXEUY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0YXRlCnEVKYFxFn1xFyhVBmFkZGluZ3EYiVUCZGJxGVUHZGVmYXVsdHEadWJVB2NvbnRlbnRxG1ghAAAASmFraSBqZXN0IHBvcHJhd255IERPQ1RZUEUgSFRNTDU/VQZwb2ludHNxHEc/8AAAAAAAAFUEdGltZXEdTlULY2F0ZWdvcnlfaWRxHooBAVUCaWRxH4oBAVUPX2NhdGVnb3J5X2NhY2hlcSBoD2NhdGhlbmEudGVzdHMubW9kZWxzCkNhdGVnb3J5CnEhaBFOh1JxIn1xIyhVBG5hbWVxJFgEAAAASFRNTFULX3Rlc3RfY2FjaGVxJWgPY2F0aGVuYS50ZXN0cy5tb2RlbHMKVGVzdApxJmgRTodScSd9cSgoVQxnM19zdGFydHNfYXRxKYoBPFUHaXNfZGVtb3EqiFUTY2FuX3Jldmlld19taXN0YWtlc3EriFULY2FuX2dvX2JhY2txLIhVDmlzX211bHRpY2hvaWNlcS2IaBRoFSmBcS59cS8oaBiJaBloGnViaCRYFQAAAFRlY2hub2xvZ2llIHNpZWNpIFdlYlUMZzVfc3RhcnRzX2F0cTCKAWBVDWczNV9zdGFydHNfYXRxMYoBQlUNZzQ1X3N0YXJ0c19hdHEyigFWaB2KArAEVRRpc190aW1lX3Blcl9xdWVzdGlvbnEziWgfigEBVQxnNF9zdGFydHNfYXRxNIoBTFUIb3duZXJfaWSKAQN1YlUPcXVlc3Rpb25fYW1vdW50cTWKAQZoFGgVKYFxNn1xNyhoGIloGWgadWJVB3Rlc3RfaWRxOIoBAWgfigEBdWJ1Yl1xOSiJiYmJZWgPaBBoEU6HUnE6fXE7KGgUaBUpgXE8fXE9KGgYiWgZaBp1YmgbWD8AAABKYWtpZSB0YWdpIG9ib3dpxIV6a293byBtdXN6xIUgcG9qYXdpxIcgc2nEmSB3IGRva3VtZW5jaWUgSFRNTD9oHEc/8AAAAAAAAGgdTmgeigEBaB+KAQJoIGgidWJdcT4oiYmJiWVoD2gQaBFOh1JxP31xQChoFGgVKYFxQX1xQihoGIloGWgadWJoG1gkAAAAS3TDs3J5Y2ggdGFnw7N3IE5JRSBkZWZpbml1amUgSFRNTDU/aBxHP/AAAAAAAABoHU5oHooBAWgfigEDaCBoInViXXFDKImJiYllaA9oEGgRTodScUR9cUUoaBRoFSmBcUZ9cUcoaBiJaBloGnViaBtYLQAAAEpha2llIHRhZ2kgbW/FvG5hIHN0b3Nvd2HEhyB3ZXduxIV0cnogPGhlYWQ+P2gcRz/wAAAAAAAAaB1OaB6KAQFoH4oBB2ggaCJ1Yl1xSCiJiYmJZWgPaBBoEU6HUnFJfXFKKGgUaBUpgXFLfXFMKGgYiWgZaBp1YmgbWJkAAABPZHN5xYJhY3ogaGlwZXJ0ZWtzdG93eSB6IG1pZWpzY2EgIlRla3N0IG9kc3nFgmFjemEiIGRvIG1pZWpzY2EgIk1pZWpzY2Ugb2Rlc8WCYW5pYSIgdyByYW1hY2ggdGVqIHNhbWVqIHN0cm9ueSBIVE1MIGplc3QgcmVhbGl6b3dhbnkgemEgcG9tb2PEhSBza8WCYWRuaT9oHEc/8AAAAAAAAGgdTmgeigEBaB+KAQ1oIGgidWJdcU0oiYmJiWVoD2gQaBFOh1JxTn1xTyhoFGgVKYFxUH1xUShoGIloGWgadWJoG1hmAAAARHluYW1pY3puxIUgem1pYW7EmSB3eXNva2/Fm2NpIG9icmF6a2EgbyBpZGVudHlmaWthdG9yemUgaWQ9Im15SW1nIiB6YSBwb21vY8SFIEhUTUwgRE9NIHJlYWxpenVqZSBrb2Q6aBxHP/AAAAAAAABoHU5oHooBA2gfigEPaCBoD2ghaBFOh1JxUn1xUyhoJFgIAAAASFRNTCBET01oJWgnaDWKAQJoFGgVKYFxVH1xVShoGIloGWgadWJoOIoBAWgfigEDdWJ1Yl1xViiJiYmJZWgPaBBoEU6HUnFXfXFYKGgUaBUpgXFZfXFaKGgYiWgZaBp1YmgbWFoAAABEeW5hbWljem7EhSB6bWlhbsSZIG9icmF6a2EgbyBpZGVudHlmaWthdG9yemUgaWQ9Im15SW1nIiB6YSBwb21vY8SFIEhUTUwgRE9NIHJlYWxpenVqZSBrb2RoHEc/8AAAAAAAAGgdTmgeigEDaB+KARFoIGhSdWJdcVsoiYmJiWVoD2gQaBFOh1JxXH1xXShoFGgVKYFxXn1xXyhoGIloGWgadWJoG1gpAAAAU2VrY2phIGRhbnljaCB3IGrEmXp5a3UgWE1MIG1hIHN0cnVrdHVyxJloHEc/8AAAAAAAAGgdTmgeigEEaB+KARVoIGgPaCFoEU6HUnFgfXFhKGgkWAMAAABYTUxoJWgnaDWKAQNoFGgVKYFxYn1xYyhoGIloGWgadWJoOIoBAWgfigEEdWJ1Yl1xZCiJiYmJZWgPaBBoEU6HUnFlfXFmKGgUaBUpgXFnfXFoKGgYiWgZaBp1YmgbWLUAAABXIHpld27EmXRyem5laiBkZWZpbmljamkgdHlwdSBkb2t1bWVudHUgKERURCkgZG8ga3TDs3JlaiBvZHdvxYJ1amUgc2nEmSBwbGlrIFhNTCB3IHBpZXJ3c3plaiBsaW5paSBqZXN0IHphcGlzIDwhRUxFTUVOVCBib29rcyAoYm9vaykrPi4gS3TDs3JlIHBvbmnFvHN6ZSBzdHdpZXJkemVuaWUgamVzdCBwcmF3ZHppd2U/aBxHP/AAAAAAAABoHU5oHooBBGgfigEXaCBoYHViXXFpKImJiYllaA9oEGgRTodScWp9cWsoaBRoFSmBcWx9cW0oaBiJaBloGnViaBtYUQAAAEt0w7NyYSBrb25zdHJ1a2NqYSBza8WCYWRuaSB0eXB1IHrFgm/FvG9uZWdvIHcgc2NoZW1hY2llIFhNTCBTY2hlbWEgamVzdCBwb3ByYXduYWgcRz/wAAAAAAAAaB1OaB6KAQVoH4oBGWggaA9oIWgRTodScW59cW8oaCRYBAAAAFhTTFRoJWgnaDWKAQJoFGgVKYFxcH1xcShoGIloGWgadWJoOIoBAWgfigEFdWJ1Yl1xciiJiYmJZWgPaBBoEU6HUnFzfXF0KGgUaBUpgXF1fXF2KGgYiWgZaBp1YmgbWK0AAABXIHRlY2hub2xvZ2lpIEFKQVggZGxhIHVzxYJ1Z2kgR29vZ2xlIE1hcHMgdHdvcnplbmllIG9iaWVrdHUgbWFweSBrbGFzeSBHTWFwMiBpIHdzdGF3aWVuaWUgZ28gZG8gZGl2LWEgeiBpZGVudHlmaWthdG9yZW0gbXlNYXAgb2RieXdhIHNpxJkgemEgcG9tb2PEhSBrb2R1IGrEmXp5a2EgSmF2YVNjcmlwdGgcRz/wAAAAAAAAaB1OaB6KAQdoH4oBHGggaA9oIWgRTodScXd9cXgoaCRYBAAAAEFKQVhoJWgnaDWKAQVoFGgVKYFxeX1xeihoGIloGWgadWJoOIoBAWgfigEHdWJ1Yl1xeyiJiYmJZWgPaBBoEU6HUnF8fXF9KGgUaBUpgXF+fXF/KGgYiWgZaBp1YmgbWC4AAABPYmlla3QgWE1MSHR0cFJlcXVlc3QgdyB0ZWNobm9sb2dpaSBBamF4IG1vxbxlaBxHP/AAAAAAAABoHU5oHooBB2gfigEeaCBod3ViXXGAKImJiYllaA9oEGgRTodScYF9cYIoaBRoFSmBcYN9cYQoaBiJaBloGnViaBtYoQAAAFcgdGVjaG5vbG9naWkgQUpBWCBwcnp5IHJlYWxpemFjamkgxbzEhWRhbmlhIHR5cHUgR0VUIGRvZGFqZSBzacSZIGRvIGtvxYRjYSBhZHJlc3UgVVJMIGRvZGF0a293eSwgbmljIG5pZSB6bmFjesSFY3kgcGFyYW1ldHIgeiBsb3Nvd8SFIHdhcnRvxZtjacSFLiBXIGpha2ltIGNlbHU/aBxHP/AAAAAAAABoHU5oHooBB2gfigEgaCBod3ViXXGFKImJiYllaA9oEGgRTodScYZ9cYcoaBRoFSmBcYh9cYkoaBiJaBloGnViaBtYZwAAAERsYSB0YWJsaWN5IGrEmXp5a2EgUEhQIHpkZWZpbmlvd2FuZWogamFrbyAkYT1hcnJheSgiYSI9PjU1LCAiYiI9PjIyKTsgcG9sZWNlbmllIGVjaG8gJGJbYV07IHd5xZt3aWV0bGloHEc/8AAAAAAAAGgdTmgeigEGaB+KASFoIGgPaCFoEU6HUnGKfXGLKGgkWAMAAABQSFBoJWgnaDWKAQZoFGgVKYFxjH1xjShoGIloGWgadWJoOIoBAWgfigEGdWJ1Yl1xjiiJiYmJZWgPaBBoEU6HUnGPfXGQKGgUaBUpgXGRfXGSKGgYiWgZaBp1YmgbWFwAAABXIGrEmXp5a3UgUEhQIGZ1bmtjamEgZm9wZW4oIm15RmlsZS50eHQiLCAiYSIpIHBvendhbGEgbmEgb3R3YXJjaWUgcGxpa3UgbXlGaWxlLnR4dCB3IHRyeWJpZWgcRz/wAAAAAAAAaB1OaB6KAQZoH4oBImggaIp1Yl1xkyiJiYmJZWgPaBBoEU6HUnGUfXGVKGgUaBUpgXGWfXGXKGgYiWgZaBp1YmgbWEEAAABLdMOzcmEgc3RydWt0dXJhIGrEmXp5a2EgUEhQIGplc3QgcG9wcmF3bmEgcG9kIHd6Z2zEmWRlbSBza8WCYWRuaWgcRz/wAAAAAAAAaB1OaB6KAQZoH4oBI2ggaIp1Yl1xmCiJiYmJZWgPaBBoEU6HUnGZfXGaKGgUaBUpgXGbfXGcKGgYiWgZaBp1YmgbWFMAAABaYXBpcyBkbyBwbGlrdSBkcnpld2EgRE9NIHpkZWZpbmlvd2FuZWdvIHBvZCB6bWllbm7EhSAkZG9tIHcgasSZenlrdSBQSFAgdW1vxbxsaXdpYWgcRz/wAAAAAAAAaB1OaB6KAQZoH4oBJ2ggaIp1Yl1xnSiJiYmJZWgPaBBoEU6HUnGefXGfKGgUaBUpgXGgfXGhKGgYiWgZaBp1YmgbWCEAAABJbnRlcmZlanMgU2ltcGxlWE1MIHcgasSZenlrdSBQSFBoHEc/8AAAAAAAAGgdTmgeigEGaB+KAShoIGiKdWJdcaIoiYmJiWVoD2gQaBFOh1Jxo31xpChoFGgVKYFxpX1xpihoGIloGWgadWJoG1hbAAAASmFrYSBqZXN0IHBvcHJhd25hIHNrxYJhZG5pYSBvZHdvxYJhbmlhIHcgZG9rdW1lbmNpZSBYSFRNTCBkbyB6ZXduxJl0cnpuZWdvIGFya3VzemEgc3R5bMOzd2gcRz/wAAAAAAAAaB1OaB6KAQFoH4oBKmggaCJ1Yl1xpyiJiYmJZWgPaBBoEU6HUnGofXGpKGgUaBUpgXGqfXGrKGgYiWgZaBp1YmgbWDwAAABKYWsgbW/FvG5hIHV0d29yennEhyBpbnN0YWNqxJkgb2JpZWt0dSB3IGrEmXp5a3UgSmF2YVNjcmlwdD9oHEc/8AAAAAAAAGgdTmgeigECaB+KATRoIGgPaCFoEU6HUnGsfXGtKGgkWAoAAABKYXZhU2NyaXB0aCVoJ2g1igECaBRoFSmBca59ca8oaBiJaBloGnViaDiKAQFoH4oBAnVidWJdcbAoiYmJiWVoD2gQaBFOh1JxsX1xsihoFGgVKYFxs31xtChoGIloGWgadWJoG1hTAAAAS3TDs3JlIHogcG9uacW8c3p5Y2ggcHJhd2R6aXdlIHPEhSB3IHN0b3N1bmt1IGRvIGZ1bmtjamkgZXZhbCgpIGrEmXp5a2EgSmF2YVNjcmlwdD9oHEc/8AAAAAAAAGgdTmgeigECaB+KATdoIGisdWJdcbUoiYmJiWVoD2gQaBFOh1Jxtn1xtyhoFGgVKYFxuH1xuShoGIloGWgadWJoG1guAAAASmFraSBqZXN0IHd5bmlrIG9wZXJhY2ppIHt9ICsge30gdyBKYXZhU2NyaXB0P2gcRz/wAAAAAAAAaB1OaB6KAQpoH4oBO2ggaA9oIWgRTodScbp9cbsoaCRYDAAAAFB5dGFuaWEgbmEgNWglaCdoNYoBAWgUaBUpgXG8fXG9KGgYiWgZaBp1Ymg4igEBaB+KAQp1YnViXXG+KImJiYllaA9oEGgRTodScb99ccAoaBRoFSmBccF9ccIoaBiJaBloGnViaBtYYgAAAEphayBwb3dpbm55IGJ5xIcgdXN0YXdpb25lIHByYXdhIGRvc3TEmXB1IGRvIGthdGFsb2d1IHcga3TDs3J5bSB1bWllc3pjem9uZSBzxIUgcGxpa2kgc2Vyd2lzdSBXV1c/aBxHP/AAAAAAAABoHU5oHooBC2gfigFBaCBoD2ghaBFOh1Jxw31xxChoJFgPAAAAT2fDs2xub3dvanNrb3dlaCVoJ2g1igEBaBRoFSmBccV9ccYoaBiJaBloGnViaDiKAQFoH4oBC3VidWJdcccoiYmJiWVoD2gQaBFOh1JxyH1xyShoFGgVKYFxyn1xyyhoGIloGWgadWJoG1hBAAAAS3TDs3J5IHphcGlzIENTUyBqZXN0IHBvcHJhd255IHByenkgcG96eWNqb25vd2FuaXUgYmV6d3pnbMSZZG55bT9oHEc/8AAAAAAAAGgdTmgeigEMaB+KAUVoIGgPaCFoEU6HUnHMfXHNKGgkWAMAAABDU1NoJWgnaDWKAQJoFGgVKYFxzn1xzyhoGIloGWgadWJoOIoBAWgfigEMdWJ1Yl1x0CiJiYmJZWgPaBBoEU6HUnHRfXHSKGgUaBUpgXHTfXHUKGgYiWgZaBp1YmgbWFEAAABLdMOzcnkgeiBwb25pxbxzenljaCBzcG9zb2LDs3cgb2tyZcWbbGVuaWEga29sb3J1IGN6ZXJ3b25lZ28gdyBDU1MgamVzdCBwb3ByYXdueT9oHEc/8AAAAAAAAGgdTmgeigEMaB+KAUloIGjMdWJdcdUoiYmJiWVoD2gQaBFOh1Jx1n1x1yhoFGgVKYFx2H1x2ShoGIloGWgadWJoG1hcAAAAS3TDs3J5IHplIHNwb3NvYsOzdyBwb2JyYW5pYSBkYW55Y2ggeiB6YXNvYnUgd3lrb25hbmVnbyB6YXB5dGFuaWEgTXlTUUwgdyBQSFAgamVzdCBwb3ByYXdueT9oHEc/8AAAAAAAAGgdTmgeigEGaB+KAUpoIGiKdWJdcdooiYmJiWVoD2gQaBFOh1Jx231x3ChoFGgVKYFx3X1x3ihoGIloGWgadWJoG1hUAAAAQ28gem5hY3p5IGF0cnlidXQgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWwiIHcgZWxlbWVuY2llIDx4c2w6c3R5bGVzaGVldD4/aBxHP/AAAAAAAABoHU5oHooBBWgfigFNaCBobnViXXHfKImJiYllaA9oEGgRTodSceB9ceEoaBRoFSmBceJ9ceMoaBiJaBloGnViaBtYMQAAAEpha2kgcm9kemFqIGRhbnljaCBvZGJpZXJhxIcgbW/FvG5hIHBvcHJ6ZXogQUpBWD9oHEc/8AAAAAAAAGgdTmgeigEHaB+KAVBoIGh3dWJdceQoiYmJiWVoD2gQaBFOh1Jx5X1x5ihoFGgVKYFx531x6ChoGIloGWgadWJoG1hmAAAAVyBqYWtpbSBqxJl6eWt1IG1vxbxlIGJ5xIcgbmFwaXNhbnkga29kIGt0w7NyeSBwbyBzdHJvbmllIHNlcndlcmEgb2JzxYJ1Z2l3YcWCIGLEmWR6aWUgemFweXRhbmlhIEFKQVg/aBxHP/AAAAAAAABoHU5oHooBB2gfigFRaCBod3ViXXHpKImJiYllaA9oEGgRTodScep9cesoaBRoFSmBcex9ce0oaBiJaBloGnViaBtYNAAAAEpha8SFIHByemV3YWfEmSBtYWrEhSBwYXJzZXJ5IFNBWCBuYWQgcGFyc2VyYW1pIERPTT9oHEc/8AAAAAAAAGgdTmgeigEEaB+KAVVoIGhgdWJdce4oiYmJiWV1VQdhbnN3ZXJzce99cfAoaBJdcfEoaA9jYXRoZW5hLnRlc3RzLm1vZGVscwpBbnN3ZXIKcfJoEU6HUnHzfXH0KGgUaBUpgXH1fXH2KGgYiWgZaBp1YlUIaXNfcmlnaHRx94loG1hcAAAAPCFET0NUWVBFIGh0bWwgUFVCTElDICItLy9XM0MvL0RURCBYSFRNTCAyLjAvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvTWFya1VwL0RURC94aHRtbDIuZHRkIj5VD19xdWVzdGlvbl9jYWNoZXH4aBJoH4oBBFULcXVlc3Rpb25faWRx+YoBAXViaA9o8mgRTodScfp9cfsoaBRoFSmBcfx9cf0oaBiJaBloGnViaPeIaBtYDwAAADwhRE9DVFlQRSBIVE1MPmj4aBJoH4oBAWj5igEBdWJoD2jyaBFOh1Jx/n1x/yhoFGgVKYFyAAEAAH1yAQEAAChoGIloGWgadWJo94loG1haAAAAPCFET0NUWVBFIEhUTUwgUFVCTElDICItLy9XNEMvL0RURCBIVE1MIDQuMDEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvVFIvaHRtbDQvc3RyaWN0LmR0ZCI+aPhoEmgfigEDaPmKAQF1YmgPaPJoEU6HUnICAQAAfXIDAQAAKGgUaBUpgXIEAQAAfXIFAQAAKGgYiWgZaBp1Ymj3iGgbWA8AAAA8IWRvY3R5cGUgaHRtbD5o+GgSaB+KAQJo+YoBAXViZWg6XXIGAQAAKGgPaPJoEU6HUnIHAQAAfXIIAQAAKGgUaBUpgXIJAQAAfXIKAQAAKGgYiWgZaBp1Ymj3iWgbWAMAAAA8cD5o+Gg6aB+KAQho+YoBAnViaA9o8mgRTodScgsBAAB9cgwBAAAoaBRoFSmBcg0BAAB9cg4BAAAoaBiJaBloGnViaPeIaBtYBwAAADx0aXRsZT5o+Gg6aB+KAQZo+YoBAnViaA9o8mgRTodScg8BAAB9chABAAAoaBRoFSmBchEBAAB9chIBAAAoaBiJaBloGnViaPeJaBtYBQAAADxkaXY+aPhoOmgfigEHaPmKAQJ1YmgPaPJoEU6HUnITAQAAfXIUAQAAKGgUaBUpgXIVAQAAfXIWAQAAKGgYiWgZaBp1Ymj3iGgbWAYAAAA8aHRtbD5o+Gg6aB+KAQVo+YoBAnViZWg/XXIXAQAAKGgPaPJoEU6HUnIYAQAAfXIZAQAAKGgUaBUpgXIaAQAAfXIbAQAAKGgYiWgZaBp1Ymj3iWgbWAQAAAA8ZW0+aPhoP2gfigEMaPmKAQN1YmgPaPJoEU6HUnIcAQAAfXIdAQAAKGgUaBUpgXIeAQAAfXIfAQAAKGgYiWgZaBp1Ymj3iGgbWAQAAAA8aDc+aPhoP2gfigEKaPmKAQN1YmgPaPJoEU6HUnIgAQAAfXIhAQAAKGgUaBUpgXIiAQAAfXIjAQAAKGgYiWgZaBp1Ymj3iGgbWAYAAAA8Zm9udD5o+Gg/aB+KAQto+YoBA3ViaA9o8mgRTodSciQBAAB9ciUBAAAoaBRoFSmBciYBAAB9cicBAAAoaBiJaBloGnViaPeJaBtYBgAAADxtZXRhPmj4aD9oH4oBCWj5igEDdWJlaERdcigBAAAoaA9o8mgRTodScikBAAB9cioBAAAoaBRoFSmBcisBAAB9ciwBAAAoaBiJaBloGnViaPeIaBtYBgAAADxtZXRhPmj4aERoH4oBGWj5igEHdWJoD2jyaBFOh1JyLQEAAH1yLgEAAChoFGgVKYFyLwEAAH1yMAEAAChoGIloGWgadWJo94hoG1gHAAAAPHN0eWxlPmj4aERoH4oBG2j5igEHdWJoD2jyaBFOh1JyMQEAAH1yMgEAAChoFGgVKYFyMwEAAH1yNAEAAChoGIloGWgadWJo94loG1gFAAAAPGRpdj5o+GhEaB+KARpo+YoBB3ViaA9o8mgRTodScjUBAAB9cjYBAAAoaBRoFSmBcjcBAAB9cjgBAAAoaBiJaBloGnViaPeIaBtYCAAAADxzY3JpcHQ+aPhoRGgfigEcaPmKAQd1YmVoSV1yOQEAAChoD2jyaBFOh1JyOgEAAH1yOwEAAChoFGgVKYFyPAEAAH1yPQEAAChoGIloGWgadWJo94loG1hIAAAAPGEgaHJlZj0iI215SUQiPlRla3N0IG9kc3nFgmFjemE8L2E+PGEgaWQ9IiNteUlEIj5NaWVqc2NlIG9kZXPFgmFuaWE8L2E+aPhoSWgfigEqaPmKAQ11YmgPaPJoEU6HUnI+AQAAfXI/AQAAKGgUaBUpgXJAAQAAfXJBAQAAKGgYiWgZaBp1Ymj3iGgbWEcAAAA8YSBocmVmPSIjbXlJRCI+VGVrc3Qgb2RzecWCYWN6YTwvYT48YSBpZD0ibXlJRCI+TWllanNjZSBvZGVzxYJhbmlhPC9hPmj4aEloH4oBK2j5igENdWJoD2jyaBFOh1JyQgEAAH1yQwEAAChoFGgVKYFyRAEAAH1yRQEAAChoGIloGWgadWJo94loG1hHAAAAPGEgaHJlZj0ibXlJRCI+VGVrc3Qgb2RzecWCYWN6YTwvYT48YSBpZD0iI215SUQiPk1pZWpzY2Ugb2Rlc8WCYW5pYTwvYT5o+GhJaB+KASlo+YoBDXViaA9o8mgRTodSckYBAAB9ckcBAAAoaBRoFSmBckgBAAB9ckkBAAAoaBiJaBloGnViaPeJaBtYRgAAADxhIGhyZWY9Im15SUQiPlRla3N0IG9kc3nFgmFjemE8L2E+PGEgaWQ9Im15SUQiPk1pZWpzY2Ugb2Rlc8WCYW5pYTwvYT5o+GhJaB+KASxo+YoBDXViZWhOXXJKAQAAKGgPaPJoEU6HUnJLAQAAfXJMAQAAKGgUaBUpgXJNAQAAfXJOAQAAKGgYiWgZaBp1Ymj3iWgbWDMAAABkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnbXlJbWcnKS5zcmMgPSAiMzAwIjto+GhOaB+KATRo+YoBD3ViaA9o8mgRTodSck8BAAB9clABAAAoaBRoFSmBclEBAAB9clIBAAAoaBiJaBloGnViaPeJaBtYMwAAAGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteUltZycpLmlubmVySFRNTCA9ICIzMDAiO2j4aE5oH4oBMWj5igEPdWJoD2jyaBFOh1JyUwEAAH1yVAEAAChoFGgVKYFyVQEAAH1yVgEAAChoGIloGWgadWJo94loG1g2AAAAZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ215SW1nJykuaGVpZ2h0ID0gIjMwMCI7aPhoTmgfigEyaPmKAQ91YmgPaPJoEU6HUnJXAQAAfXJYAQAAKGgUaBUpgXJZAQAAfXJaAQAAKGgYiWgZaBp1Ymj3iGgbWDAAAABkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlJbWcnKS5oZWlnaHQgPSAiMzAwIjto+GhOaB+KATNo+YoBD3ViZWhXXXJbAQAAKGgPaPJoEU6HUnJcAQAAfXJdAQAAKGgUaBUpgXJeAQAAfXJfAQAAKGgYiWgZaBp1Ymj3iWgbWDkAAABkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlJbWcnKS5pbm5lckhUTUwgPSAiaW1hZ2UuZ2lmIjto+GhXaB+KATlo+YoBEXViaA9o8mgRTodScmABAAB9cmEBAAAoaBRoFSmBcmIBAAB9cmMBAAAoaBiJaBloGnViaPeJaBtYOQAAAGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdteUltZycpLnNyYyA9ICJpbWFnZS5naWYiO2j4aFdoH4oBPGj5igERdWJoD2jyaBFOh1JyZAEAAH1yZQEAAChoFGgVKYFyZgEAAH1yZwEAAChoGIloGWgadWJo94loG1g/AAAAZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ215SW1nJykuaW5uZXJIVE1MID0gImltYWdlLmdpZiI7aPhoV2gfigE6aPmKARF1YmgPaPJoEU6HUnJoAQAAfXJpAQAAKGgUaBUpgXJqAQAAfXJrAQAAKGgYiWgZaBp1Ymj3iGgbWDMAAABkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlJbWcnKS5zcmMgPSAiaW1hZ2UuZ2lmIjto+GhXaB+KATto+YoBEXViZWhcXXJsAQAAKGgPaPJoEU6HUnJtAQAAfXJuAQAAKGgUaBUpgXJvAQAAfXJwAQAAKGgYiWgZaBp1Ymj3iGgbWBsAAAA8IVtDREFUQVsgZG93b2xuZSB6bmFraSBdXT5o+GhcaB+KAUdo+YoBFXViaA9o8mgRTodScnEBAAB9cnIBAAAoaBRoFSmBcnMBAAB9cnQBAAAoaBiJaBloGnViaPeJaBtYGwAAADx4bWw6Q0RBVEFbIGRvd29sbmUgem5ha2ldPmj4aFxoH4oBRWj5igEVdWJoD2jyaBFOh1JydQEAAH1ydgEAAChoFGgVKYFydwEAAH1yeAEAAChoGIloGWgadWJo94loG1ggAAAAPFBDREFUQT4gZG93b2xuZSB6bmFraSA8L1BDREFUQT5o+GhcaB+KAUZo+YoBFXViaA9o8mgRTodScnkBAAB9cnoBAAAoaBRoFSmBcnsBAAB9cnwBAAAoaBiJaBloGnViaPeJaBtYHgAAADxDREFUQT4gZG93b2xuZSB6bmFraSA8L0NEQVRBPmj4aFxoH4oBSGj5igEVdWJlaGVdcn0BAAAoaA9o8mgRTodScn4BAAB9cn8BAAAoaBRoFSmBcoABAAB9coEBAAAoaBiJaBloGnViaPeJaBtYLgAAAEF0cnlidXQgbyBuYXp3aWUgYm9vayBtdXNpIG1pZcSHIHdhcnRvxZvEhyAiKyJo+GhlaB+KAVBo+YoBF3ViaA9o8mgRTodScoIBAAB9coMBAAAoaBRoFSmBcoQBAAB9coUBAAAoaBiJaBloGnViaPeJaBtYQAAAAEVsZW1lbnQgZ8WCw7N3bnkgbyBuYXp3aWUgYm9va3MgbXVzaSBtaWXEhyBhdHJ5YnV0IG8gbmF6d2llIGJvb2to+GhlaB+KAU9o+YoBF3ViaA9o8mgRTodScoYBAAB9cocBAAAoaBRoFSmBcogBAAB9cokBAAAoaBiJaBloGnViaPeIaBtYNAAAAEVsZW1lbnQgZ8WCw7N3bnkgdyBwbGlrdSBYTUwgbXVzaSBuYXp5d2HEhyBzacSZIGJvb2to+GhlaB+KAU1o+YoBF3ViaA9o8mgRTodScooBAAB9cosBAAAoaBRoFSmBcowBAAB9co0BAAAoaBiJaBloGnViaPeIaBtYVgAAAFpuYWN6bmlrIGJvb2tzIG11c2kgd3lzdMSFcGnEhyBwcnp5bmFqbW5pZWogamVkZW4gcmF6LCBhbGUgbW/FvGUgd3lzdMSFcGnEhyB3aWVsZSByYXp5aPhoZWgfigFOaPmKARd1YmVoal1yjgEAAChoD2jyaBFOh1JyjwEAAH1ykAEAAChoFGgVKYFykQEAAH1ykgEAAChoGIloGWgadWJo94loG1hNAAAAPHhzZDplbGVtZW50IG5hbWU9Ik5hbWUiPjx4c2Q6c2ltcGxlVHlwZT4gLi4uIDwveHNkOnNpbXBsZVR5cGU+PC94c2Q6ZWxlbWVudD5o+GhqaB+KAVZo+YoBGXViaA9o8mgRTodScpMBAAB9cpQBAAAoaBRoFSmBcpUBAAB9cpYBAAAoaBiJaBloGnViaPeJaBtYRQAAADx4c2Q6ZWxlbWVudCBuYW1lPSJOYW1lIj48c2ltcGxlVHlwZT4gLi4uIDwvc2ltcGxlVHlwZT48L3hzZDplbGVtZW50Pmj4aGpoH4oBWGj5igEZdWJoD2jyaBFOh1JylwEAAH1ymAEAAChoFGgVKYFymQEAAH1ymgEAAChoGIloGWgadWJo94hoG1hPAAAAPHhzZDplbGVtZW50IG5hbWU9Ik5hbWUiPjx4c2Q6Y29tcGxleFR5cGU+IC4uLiA8L3hzZDpjb21wbGV4VHlwZT48L3hzZDplbGVtZW50Pmj4aGpoH4oBVWj5igEZdWJoD2jyaBFOh1JymwEAAH1ynAEAAChoFGgVKYFynQEAAH1yngEAAChoGIloGWgadWJo94loG1hTAAAAPHhzZDplbGVtZW50IG5hbWU9Ik5hbWUiPjx4c2Q6cHJpbWl0aXZlVHlwZT4gLi4uIDwveHNkOnByaW1pdGl2ZVR5cGU+PC94c2Q6ZWxlbWVudD5o+GhqaB+KAVdo+YoBGXViZWhzXXKfAQAAKGgPaPJoEU6HUnKgAQAAfXKhAQAAKGgUaBUpgXKiAQAAfXKjAQAAKGgYiWgZaBp1Ymj3iWgbWC0AAABtYXAgPSBuZXcgR01hcDIoZGl2LmdldEVsZW1lbnRCeUlkKCJteU1hcCIpKTto+GhzaB+KAWVo+YoBHHViaA9o8mgRTodScqQBAAB9cqUBAAAoaBRoFSmBcqYBAAB9cqcBAAAoaBiJaBloGnViaPeJaBtYMAAAAG1hcCA9IG5ldyBHTWFwMih3aW5kb3cuZ2V0RWxlbWVudEJ5SWQoIm15TWFwIikpO2j4aHNoH4oBZGj5igEcdWJoD2jyaBFOh1JyqAEAAH1yqQEAAChoFGgVKYFyqgEAAH1yqwEAAChoGIloGWgadWJo94hoG1gyAAAAbWFwID0gbmV3IEdNYXAyKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCJteU1hcCIpKTto+GhzaB+KAWJo+YoBHHViaA9o8mgRTodScqwBAAB9cq0BAAAoaBRoFSmBcq4BAAB9cq8BAAAoaBiJaBloGnViaPeJaBtYKQAAAG1hcCA9IG5ldyBHTWFwMihnZXRFbGVtZW50QnlJZCgibXlNYXAiKSk7aPhoc2gfigFjaPmKARx1YmVofF1ysAEAAChoD2jyaBFOh1JysQEAAH1ysgEAAChoFGgVKYFyswEAAH1ytAEAAChoGIloGWgadWJo94loG1goAAAAQWpheCBuaWUgxYLEhWN6eSBzacSZIHogxbxhZG55bSBzZXJ3ZXJlbWj4aHxoH4oBbWj5igEedWJoD2jyaBFOh1JytQEAAH1ytgEAAChoFGgVKYFytwEAAH1yuAEAAChoGIloGWgadWJo94loG1gqAAAAxYHEhWN6ecSHIHNpxJkgeiBkb3dvbG55bSB6ZGFsbnltIHNlcndlcmVtaPhofGgfigFqaPmKAR51YmgPaPJoEU6HUnK5AQAAfXK6AQAAKGgUaBUpgXK7AQAAfXK8AQAAKGgYiWgZaBp1Ymj3iGgbWEQAAADFgcSFY3p5xIcgc2nEmSB6IGFkcmVzZW0gVVJMIHRlaiBzYW1laiBkb21lbnksIGNvIHd5d2/Fgnl3YW5hIHN0cm9uYWj4aHxoH4oBa2j5igEedWJoD2jyaBFOh1JyvQEAAH1yvgEAAChoFGgVKYFyvwEAAH1ywAEAAChoGIloGWgadWJo94loG1glAAAAxYHEhWN6ecSHIHNpxJkgeiBkb3dvbG55bSBhZHJlc2VtIFVSTGj4aHxoH4oBbGj5igEedWJlaIFdcsEBAAAoaA9o8mgRTodScsIBAAB9csMBAAAoaBRoFSmBcsQBAAB9csUBAAAoaBiJaBloGnViaPeJaBtYLwAAAEFieSB6d2nEmWtzennEhyBzenlia2/Fm8SHIHJlYWxpemFjamkgxbzEhWRhbmlhaPhogWgfigFyaPmKASB1YmgPaPJoEU6HUnLGAQAAfXLHAQAAKGgUaBUpgXLIAQAAfXLJAQAAKGgYiWgZaBp1Ymj3iWgbWC4AAABXIG9nw7NsZSBuaWUgc3Rvc3VqZSBzacSZIHRha2llZ28gcm96d2nEhXphbmlhaPhogWgfigF1aPmKASB1YmgPaPJoEU6HUnLKAQAAfXLLAQAAKGgUaBUpgXLMAQAAfXLNAQAAKGgYiWgZaBp1Ymj3iGgbWDsAAABBYnkgemEga2HFvGR5bSByYXplbSBiecWCbyB3eWdlbmVyb3dhbmUgbm93ZSDFvMSFZGFuaWUgSFRUUGj4aIFoH4oBc2j5igEgdWJoD2jyaBFOh1JyzgEAAH1yzwEAAChoFGgVKYFy0AEAAH1y0QEAAChoGIloGWgadWJo94hoG1hKAAAAQWJ5IHN0cm9uYSBuaWUgYnnFgmEgd2N6eXRhbmEgeiBwYW1pxJljaSBwb2RyxJljem5laiBwcnplZ2zEhWRhcmtpIChjYWNoZSlo+GiBaB+KAXRo+YoBIHViZWiGXXLSAQAAKGgPaPJoEU6HUnLTAQAAfXLUAQAAKGgUaBUpgXLVAQAAfXLWAQAAKGgYiWgZaBp1Ymj3iWgbWAIAAAAyMmj4aIZoH4oBeWj5igEhdWJoD2jyaBFOh1Jy1wEAAH1y2AEAAChoFGgVKYFy2QEAAH1y2gEAAChoGIloGWgadWJo94loG1gCAAAANTVo+GiGaB+KAXho+YoBIXViaA9o8mgRTodSctsBAAB9ctwBAAAoaBRoFSmBct0BAAB9ct4BAAAoaBiJaBloGnViaPeIaBtYHgAAAGtvbXVuaWthdCBvIGLFgsSZZHppZSAobm90aWNlKWj4aIZoH4oBd2j5igEhdWJoD2jyaBFOh1Jy3wEAAH1y4AEAAChoFGgVKYFy4QEAAH1y4gEAAChoGIloGWgadWJo94loG1gdAAAAa29tdW5pa2F0IG8gYsWCxJlkemllIChlcnJvcilo+GiGaB+KAXZo+YoBIXViZWiPXXLjAQAAKGgPaPJoEU6HUnLkAQAAfXLlAQAAKGgUaBUpgXLmAQAAfXLnAQAAKGgYiWgZaBp1Ymj3iGgbWBsAAABEb3Bpc3l3YW5pYSBkYW55Y2ggZG8gcGxpa3Vo+GiPaB+KAX1o+YoBInViaA9o8mgRTodScugBAAB9cukBAAAoaBRoFSmBcuoBAAB9cusBAAAoaBiJaBloGnViaPeJaBtYFAAAAERvIGN6eXRhbmlhIGkgemFwaXN1aPhoj2gfigF8aPmKASJ1YmgPaPJoEU6HUnLsAQAAfXLtAQAAKGgUaBUpgXLuAQAAfXLvAQAAKGgYiWgZaBp1Ymj3iGgbWA8AAABUeWxrbyBkbyB6YXBpc3Vo+GiPaB+KAXto+YoBInViaA9o8mgRTodScvABAAB9cvEBAAAoaBRoFSmBcvIBAAB9cvMBAAAoaBiJaBloGnViaPeJaBtYEAAAAFR5bGtvIGRvIG9kY3p5dHVo+GiPaB+KAXpo+YoBInViZWiUXXL0AQAAKGgPaPJoEU6HUnL1AQAAfXL2AQAAKGgUaBUpgXL3AQAAfXL4AQAAKGgYiWgZaBp1Ymj3iWgbWDQAAAA8P3BocD4gJGEgPSAiSmFuIjsgPC8/PjxoMT48P3BocD4gZWNobyAkYTsgPC8/PjwvaDE+aPholGgfigKAAGj5igEjdWJoD2jyaBFOh1Jy+QEAAH1y+gEAAChoFGgVKYFy+wEAAH1y/AEAAChoGIloGWgadWJo94hoG1guAAAAPD9waHAgJGEgPSAiSmFuIjsgPz48aDE+PD9waHAgZWNobyAkYTsgPz48L2gxPmj4aJRoH4oBfmj5igEjdWJoD2jyaBFOh1Jy/QEAAH1y/gEAAChoFGgVKYFy/wEAAH1yAAIAAChoGIloGWgadWJo94hoG1gdAAAAPD9waHAgJGEgPSAiSmFuIjsgZWNobyAkYTsgPz5o+GiUaB+KAX9o+YoBI3ViaA9o8mgRTodScgECAAB9cgICAAAoaBRoFSmBcgMCAAB9cgQCAAAoaBiJaBloGnViaPeJaBtYIAAAADw/cGhwPiAkYSA9ICJKYW4iOyBlY2hvICRhOyA8Lz8+aPholGgfigKBAGj5igEjdWJlaJldcgUCAAAoaA9o8mgRTodScgYCAAB9cgcCAAAoaBRoFSmBcggCAAB9cgkCAAAoaBiJaBloGnViaPeIaBtYGwAAACRkb20tPnNhdmUoJ2ZpbGVOYW1lLnhtbCcpO2j4aJloH4oCjwBo+YoBJ3ViaA9o8mgRTodScgoCAAB9cgsCAAAoaBRoFSmBcgwCAAB9cg0CAAAoaBiJaBloGnViaPeJaBtYLQAAAFBIUCBuaWUgdW1vxbxsaXdpYSB6YXBpc3UgZG8gcGxpa3UgZHJ6ZXdhIERPTWj4aJloH4oCkQBo+YoBJ3ViaA9o8mgRTodScg4CAAB9cg8CAAAoaBRoFSmBchACAAB9chECAAAoaBiJaBloGnViaPeJaBtYGwAAACRkb20tPm9wZW4oJ2ZpbGVOYW1lLnhtbCcpO2j4aJloH4oCkABo+YoBJ3ViaA9o8mgRTodSchICAAB9chMCAAAoaBRoFSmBchQCAAB9chUCAAAoaBiJaBloGnViaPeJaBtYEAAAACRkb20tPnNhdmVYTUwoKTto+GiZaB+KAo4AaPmKASd1YmVonl1yFgIAAChoD2jyaBFOh1JyFwIAAH1yGAIAAChoFGgVKYFyGQIAAH1yGgIAAChoGIloGWgadWJo94hoG1gcAAAAT2JzxYJ1Z3VqZSBwcnplc3RyemVuaWUgbmF6d2j4aJ5oH4oCkwBo+YoBKHViaA9o8mgRTodSchsCAAB9chwCAAAoaBRoFSmBch0CAAB9ch4CAAAoaBiJaBloGnViaPeIaBtYHQAAAFVtb8W8bGl3aWEgemFwaXMgZG8gcGxpa3UgWE1MaPhonmgfigKUAGj5igEodWJoD2jyaBFOh1JyHwIAAH1yIAIAAChoFGgVKYFyIQIAAH1yIgIAAChoGIloGWgadWJo94loG1gnAAAATmllIG1hIHRha2llZ28gaW50ZXJmZWpzdSB3IGrEmXp5a3UgUEhQaPhonmgfigKVAGj5igEodWJoD2jyaBFOh1JyIwIAAH1yJAIAAChoFGgVKYFyJQIAAH1yJgIAAChoGIloGWgadWJo94loG1gfAAAASmVzdCBzdGFuZGFyZGVtIG9yZ2FuaXphY2ppIFczQ2j4aJ5oH4oCkgBo+YoBKHViZWijXXInAgAAKGgPaPJoEU6HUnIoAgAAfXIpAgAAKGgUaBUpgXIqAgAAfXIrAgAAKGgYiWgZaBp1Ymj3iWgbWEAAAAA8aGVhZCByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSJwbGlrX3N0eWxvdy5jc3MiIC8+aPhoo2gfigKbAGj5igEqdWJoD2jyaBFOh1JyLAIAAH1yLQIAAChoFGgVKYFyLgIAAH1yLwIAAChoGIloGWgadWJo94loG1hBAAAAPGxpbmsgaHJlZj0ic3R5bGVzaGVldCIgdHlwZT0idGV4dC9jc3MiIGhyZWY9InBsaWtfc3R5bG93LmNzcyIgLz5o+GijaB+KAp0AaPmKASp1YmgPaPJoEU6HUnIwAgAAfXIxAgAAKGgUaBUpgXIyAgAAfXIzAgAAKGgYiWgZaBp1Ymj3iGgbWEAAAAA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSJwbGlrX3N0eWxvdy5jc3MiIC8+aPhoo2gfigKaAGj5igEqdWJoD2jyaBFOh1JyNAIAAH1yNQIAAChoFGgVKYFyNgIAAH1yNwIAAChoGIloGWgadWJo94loG1hBAAAAPHN0eWxlIHJlbD0ic3R5bGVzaGVldCIgdHlwZT0idGV4dC9jc3MiIGhyZWY9InBsaWtfc3R5bG93LmNzcyIgLz5o+GijaB+KApwAaPmKASp1YmVoqF1yOAIAAChoD2jyaBFOh1JyOQIAAH1yOgIAAChoFGgVKYFyOwIAAH1yPAIAAChoGIloGWgadWJo94hoG1gRAAAAYSA9IG5ldyBPYmplY3QoKTto+GioaB+KAsEAaPmKATR1YmgPaPJoEU6HUnI9AgAAfXI+AgAAKGgUaBUpgXI/AgAAfXJAAgAAKGgYiWgZaBp1Ymj3iGgbWAcAAABhID0ge307aPhoqGgfigK/AGj5igE0dWJoD2jyaBFOh1JyQQIAAH1yQgIAAChoFGgVKYFyQwIAAH1yRAIAAChoGIloGWgadWJo94loG1gPAAAAYSA9IG5ldyBvYmplY3Q7aPhoqGgfigLCAGj5igE0dWJoD2jyaBFOh1JyRQIAAH1yRgIAAChoFGgVKYFyRwIAAH1ySAIAAChoGIloGWgadWJo94loG1gRAAAAYSA9IG5ldyBvYmplY3QoKTto+GioaB+KAsAAaPmKATR1YmVosV1ySQIAAChoD2jyaBFOh1JySgIAAH1ySwIAAChoFGgVKYFyTAIAAH1yTQIAAChoGIloGWgadWJo94hoG1hTAAAARnVua2NqYSB0YSB3eWtvbnVqZSBwcnpla2F6YW55IHRla3N0IGpha2J5IGJ5xYIga29kZW0gSmF2YVNjcmlwdCBpIHp3cmFjYSB3YXJ0b8WbxIdo+GixaB+KAs0AaPmKATd1YmgPaPJoEU6HUnJOAgAAfXJPAgAAKGgUaBUpgXJQAgAAfXJRAgAAKGgYiWgZaBp1Ymj3iGgbWEMAAABOaWUgamVzdCB6YWxlY2FuYSBkbyBkZWtvZG93YW5pYSBKU09OIHplIHd6Z2zEmWTDs3cgYmV6cGllY3plxYRzdHdhaPhosWgfigLMAGj5igE3dWJoD2jyaBFOh1JyUgIAAH1yUwIAAChoFGgVKYFyVAIAAH1yVQIAAChoGIloGWgadWJo94hoG1hUAAAAUHJ6eSBBSkFYIHNlcndlciBtb8W8ZSBwcnplc8WCYcSHIGRvd29sbsSFIGZ1bmtjasSZIEphdmFTY3JpcHQga3TDs3LEhSBldmFsKCkgd3lrb25haPhosWgfigLLAGj5igE3dWJoD2jyaBFOh1JyVgIAAH1yVwIAAChoFGgVKYFyWAIAAH1yWQIAAChoGIloGWgadWJo94loG1gVAAAATmllIG1hIHRha2llaiBmdW5rY2ppaPhosWgfigLOAGj5igE3dWJlaLZdcloCAAAoaA9o8mgRTodSclsCAAB9clwCAAAoaBRoFSmBcl0CAAB9cl4CAAAoaBiJaBloGnViaPeJaBtYAgAAAHt9aPhotmgfigLcAGj5igE7dWJoD2jyaBFOh1JyXwIAAH1yYAIAAChoFGgVKYFyYQIAAH1yYgIAAChoGIloGWgadWJo94loG1gBAAAAMGj4aLZoH4oC3QBo+YoBO3ViaA9o8mgRTodScmMCAAB9cmQCAAAoaBRoFSmBcmUCAAB9cmYCAAAoaBiJaBloGnViaPeJaBtYDAAAAHB1c3R5IHN0cmluZ2j4aLZoH4oC3gBo+YoBO3ViaA9o8mgRTodScmcCAAB9cmgCAAAoaBRoFSmBcmkCAAB9cmoCAAAoaBiJaBloGnViaPeIaBtYAwAAAE5hTmj4aLZoH4oC2wBo+YoBO3ViZWi/XXJrAgAAKGgPaPJoEU6HUnJsAgAAfXJtAgAAKGgUaBUpgXJuAgAAfXJvAgAAKGgYiWgZaBp1Ymj3iWgbWAoAAABkcnd4LXctLXctaPhov2gfigLxAGj5igFBdWJoD2jyaBFOh1JycAIAAH1ycQIAAChoFGgVKYFycgIAAH1ycwIAAChoGIloGWgadWJo94loG1gKAAAAZHJ3eC13eC13eGj4aL9oH4oC8gBo+YoBQXViaA9o8mgRTodScnQCAAB9cnUCAAAoaBRoFSmBcnYCAAB9cncCAAAoaBiJaBloGnViaPeJaBtYCgAAAGRyd3hyd3hyd3ho+Gi/aB+KAu8AaPmKAUF1YmgPaPJoEU6HUnJ4AgAAfXJ5AgAAKGgUaBUpgXJ6AgAAfXJ7AgAAKGgYiWgZaBp1Ymj3iGgbWAoAAABkcnd4cnctcnctaPhov2gfigLwAGj5igFBdWJlaMhdcnwCAAAoaA9o8mgRTodScn0CAAB9cn4CAAAoaBRoFSmBcn8CAAB9coACAAAoaBiJaBloGnViaPeIaBtYNQAAAGgxLnBvc2l0aW9uX2xlZnQgeyBwb3NpdGlvbjogYWJzb2x1dGU7IGxlZnQ6IC01MHB4OyB9aPhoyGgfigIAAWj5igFFdWJoD2jyaBFOh1JygQIAAH1yggIAAChoFGgVKYFygwIAAH1yhAIAAChoGIloGWgadWJo94loG1g0AAAAaDEucG9zaXRpb25fbGVmdCB7IHBvc2l0aW9uOiByZWxhdGl2ZTsgbGVmdDogNTBweDsgfWj4aMhoH4oCAQFo+YoBRXViaA9o8mgRTodScoUCAAB9coYCAAAoaBRoFSmBcocCAAB9cogCAAAoaBiJaBloGnViaPeIaBtYNAAAAGgxLnBvc2l0aW9uX2xlZnQgeyBwb3NpdGlvbjogYWJzb2x1dGU7IGxlZnQ6IDUwcHg7IH1o+GjIaB+KAv8AaPmKAUV1YmgPaPJoEU6HUnKJAgAAfXKKAgAAKGgUaBUpgXKLAgAAfXKMAgAAKGgYiWgZaBp1Ymj3iWgbWDUAAABoMS5wb3NpdGlvbl9sZWZ0IHsgcG9zaXRpb246IHJlbGF0aXZlOyBsZWZ0OiAtNTBweDsgfWj4aMhoH4oCAgFo+YoBRXViZWjRXXKNAgAAKGgPaPJoEU6HUnKOAgAAfXKPAgAAKGgUaBUpgXKQAgAAfXKRAgAAKGgYiWgZaBp1Ymj3iGgbWAQAAAByZWQ7aPho0WgfigIPAWj5igFJdWJoD2jyaBFOh1JykgIAAH1ykwIAAChoFGgVKYFylAIAAH1ylQIAAChoGIloGWgadWJo94hoG1gTAAAAcmdiYSgyNTUsIDAsIDAsIDEpO2j4aNFoH4oCEgFo+YoBSXViaA9o8mgRTodScpYCAAB9cpcCAAAoaBRoFSmBcpgCAAB9cpkCAAAoaBiJaBloGnViaPeJaBtYCAAAACMwMEZGMDA7aPho0WgfigIRAWj5igFJdWJoD2jyaBFOh1JymgIAAH1ymwIAAChoFGgVKYFynAIAAH1ynQIAAChoGIloGWgadWJo94hoG1gPAAAAcmdiKDI1NSwgMCwgMCk7aPho0WgfigIQAWj5igFJdWJlaNZdcp4CAAAoaA9o8mgRTodScp8CAAB9cqACAAAoaBRoFSmBcqECAAB9cqICAAAoaBiJaBloGnViaPeJaBtYFwAAAG15c3FsX2ZldGNoX2RhdGEoJHJlcyk7aPho1mgfigIVAWj5igFKdWJoD2jyaBFOh1JyowIAAH1ypAIAAChoFGgVKYFypQIAAH1ypgIAAChoGIloGWgadWJo94hoG1gWAAAAbXlzcWxfZmV0Y2hfcm93KCRyZXMpO2j4aNZoH4oCEwFo+YoBSnViaA9o8mgRTodScqcCAAB9cqgCAAAoaBRoFSmBcqkCAAB9cqoCAAAoaBiJaBloGnViaPeJaBtYFwAAAG15c3FsX2ZldGNoX2xpc3QoJHJlcyk7aPho1mgfigIWAWj5igFKdWJoD2jyaBFOh1JyqwIAAH1yrAIAAChoFGgVKYFyrQIAAH1yrgIAAChoGIloGWgadWJo94hoG1gYAAAAbXlzcWxfZmV0Y2hfYXJyYXkoJHJlcyk7aPho1mgfigIUAWj5igFKdWJlaNtdcq8CAAAoaA9o8mgRTodScrACAAB9crECAAAoaBRoFSmBcrICAAB9crMCAAAoaBiJaBloGnViaPeJaBtYNgAAAEVsZW1lbnR5IHcgd2VqxZtjaW93eW0gWE1MIG1hasSFIGJ5xIcgZWxlbWVudGFtaSBYSFRNTGj4aNtoH4oCHQFo+YoBTXViaA9o8mgRTodScrQCAAB9crUCAAAoaBRoFSmBcrYCAAB9crcCAAAoaBiJaBloGnViaPeIaBtYNgAAAEVsZW1lbnR5IHcgd3lqxZtjaW93eW0gWE1MIG1hasSFIGJ5xIcgZWxlbWVudGFtaSBYSFRNTGj4aNtoH4oCGwFo+YoBTXViaA9o8mgRTodScrgCAAB9crkCAAAoaBRoFSmBcroCAAB9crsCAAAoaBiJaBloGnViaPeJaBtYNAAAAEVsZW1lbnR5IHcgd2VqxZtjaW93eW0gWE1MIG1hasSFIGJ5xIcgZWxlbWVudGFtaSBURUlo+GjbaB+KAh4BaPmKAU11YmgPaPJoEU6HUnK8AgAAfXK9AgAAKGgUaBUpgXK+AgAAfXK/AgAAKGgYiWgZaBp1Ymj3iWgbWDQAAABFbGVtZW50eSB3IHd5asWbY2lvd3ltIFhNTCBtYWrEhSBiecSHIGVsZW1lbnRhbWkgVEVJaPho22gfigIcAWj5igFNdWJlaOBdcsACAAAoaA9o8mgRTodScsECAAB9csICAAAoaBRoFSmBcsMCAAB9csQCAAAoaBiJaBloGnViaPeIaBtYAwAAAFhNTGj4aOBoH4oCJAFo+YoBUHViaA9o8mgRTodScsUCAAB9csYCAAAoaBRoFSmBcscCAAB9csgCAAAoaBiJaBloGnViaPeIaBtYBAAAAEhUTUxo+GjgaB+KAiMBaPmKAVB1YmgPaPJoEU6HUnLJAgAAfXLKAgAAKGgUaBUpgXLLAgAAfXLMAgAAKGgYiWgZaBp1Ymj3iGgbWAQAAABZQU1MaPho4GgfigImAWj5igFQdWJoD2jyaBFOh1JyzQIAAH1yzgIAAChoFGgVKYFyzwIAAH1y0AIAAChoGIloGWgadWJo94hoG1gEAAAASlNPTmj4aOBoH4oCJQFo+YoBUHViZWjlXXLRAgAAKGgPaPJoEU6HUnLSAgAAfXLTAgAAKGgUaBUpgXLUAgAAfXLVAgAAKGgYiWgZaBp1Ymj3iGgbWAMAAABDKyto+GjlaB+KAigBaPmKAVF1YmgPaPJoEU6HUnLWAgAAfXLXAgAAKGgUaBUpgXLYAgAAfXLZAgAAKGgYiWgZaBp1Ymj3iGgbWAMAAABQSFBo+GjlaB+KAikBaPmKAVF1YmgPaPJoEU6HUnLaAgAAfXLbAgAAKGgUaBUpgXLcAgAAfXLdAgAAKGgYiWgZaBp1Ymj3iGgbWAQAAABKYXZhaPho5WgfigInAWj5igFRdWJoD2jyaBFOh1Jy3gIAAH1y3wIAAChoFGgVKYFy4AIAAH1y4QIAAChoGIloGWgadWJo94hoG1gKAAAASmF2YVNjcmlwdGj4aOVoH4oCKgFo+YoBUXViZWjqXXLiAgAAKGgPaPJoEU6HUnLjAgAAfXLkAgAAKGgUaBUpgXLlAgAAfXLmAgAAKGgYiWgZaBp1Ymj3iGgbWDAAAABNb8W8bGl3b8WbxIcgb2JzxYJ1Z2kgYmFyZHpvIGR1xbx5Y2ggcGxpa8OzdyBYTUxo+GjqaB+KAjkBaPmKAVV1YmgPaPJoEU6HUnLnAgAAfXLoAgAAKGgUaBUpgXLpAgAAfXLqAgAAKGgYiWgZaBp1Ymj3iWgbWDcAAABNbmllanN6eSBuYWvFgmFkIHByYWN5IHByb2dyYW1pc3R5IGRvIHByemV0d29yemVuaWEgWE1MaPho6mgfigI6AWj5igFVdWJoD2jyaBFOh1Jy6wIAAH1y7AIAAChoFGgVKYFy7QIAAH1y7gIAAChoGIloGWgadWJo94loG1gnAAAAV2nEmWtzemEgZWxhc3R5Y3pub8WbxIcgZGxhIHByb2dyYW1pc3R5aPho6mgfigI4AWj5igFVdWJoD2jyaBFOh1Jy7wIAAH1y8AIAAChoFGgVKYFy8QIAAH1y8gIAAChoGIloGWgadWJo94hoG1gaAAAATW5pZWpzemUgenXFvHljaWUgcGFtacSZY2lo+GjqaB+KAjcBaPmKAVV1YmV1VQhkZWFkbGluZXLzAgAAR0HUuolD0Q4bVQlxdWVzdGlvbnNy9AIAAF1y9QIAAChoXGiBaJ5oP2jqaNtoc2i/aE5oSWhEaHxoqGjlaJRohmg6aOBomWhlaNZoamjRaI9oEmhXaLZoo2ixaMhlVQR0ZXN0cvYCAABoJ1USdGltZV9yZW1haW5pbmdfZm9ycvcCAAB9cvgCAAAoaBJHf/AAAAAAAABoOkd/8AAAAAAAAGg/R3/wAAAAAAAAaERHf/AAAAAAAABoSUd/8AAAAAAAAGhOR3/wAAAAAAAAaFdHf/AAAAAAAABoXEd/8AAAAAAAAGhlR3/wAAAAAAAAaGpHf/AAAAAAAABoc0d/8AAAAAAAAGh8R3/wAAAAAAAAaIFHf/AAAAAAAABohkd/8AAAAAAAAGiPR3/wAAAAAAAAaJRHf/AAAAAAAABomUd/8AAAAAAAAGieR3/wAAAAAAAAaKNHf/AAAAAAAABoqEd/8AAAAAAAAGixR3/wAAAAAAAAaLZHf/AAAAAAAABov0d/8AAAAAAAAGjIR3/wAAAAAAAAaNFHf/AAAAAAAABo1kd/8AAAAAAAAGjbR3/wAAAAAAAAaOBHf/AAAAAAAABo5Ud/8AAAAAAAAGjqR3/wAAAAAAAAdVUQY3VycmVudF9xdWVzdGlvbnL5AgAASwBVHXRpbWVfb2ZfcXVlc3Rpb25fcHJlc2VudGF0aW9ucvoCAABHQdS6iBfRDg91YlUNdGVzdF9lbmRlZF9vbnL7AgAATnViLg==');

-- --------------------------------------------------------

--
-- Table structure for table `tests_testresult`
--

CREATE TABLE IF NOT EXISTS `tests_testresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_id` int(11) NOT NULL,
  `written_by_id` int(11) NOT NULL,
  `time_of_end` datetime NOT NULL,
  `grade` decimal(2,1) NOT NULL,
  `is_invalidated` tinyint(1) NOT NULL,
  `is_killed` tinyint(1) NOT NULL,
  `protocol` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_testresult_22e62ab6` (`term_id`),
  KEY `tests_testresult_35be4010` (`written_by_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tests_testresult`
--

INSERT INTO `tests_testresult` (`id`, `term_id`, `written_by_id`, `time_of_end`, `grade`, `is_invalidated`, `is_killed`, `protocol`) VALUES
(2, 7, 8, '2014-01-30 08:57:12', '4.5', 0, 0, 'gAJ9cQEoVQt0ZXN0X2VuZF9vbnECVRMyMDE0LTAxLTMwIDA4OjU3OjExVQ10ZXN0X3N0YXJ0X29ucQNVEzIwMTQtMDEtMzAgMDg6NTQ6MTFVBXNjb3JlcQRHQDwAAAAAAABVCW1heF9zY29yZXEFR0A+AAAAAAAAVQlxdWVzdGlvbnNxBl1xBygoWFwAAABLdMOzcnkgemUgc3Bvc29iw7N3IHBvYnJhbmlhIGRhbnljaCB6IHphc29idSB3eWtvbmFuZWdvIHphcHl0YW5pYSBNeVNRTCB3IFBIUCBqZXN0IHBvcHJhd255P3EIRz/wAAAAAAAAXXEJKCiIiFgWAAAAbXlzcWxfZmV0Y2hfcm93KCRyZXMpO3EKigITAXRxCyiIiFgYAAAAbXlzcWxfZmV0Y2hfYXJyYXkoJHJlcyk7cQyKAhQBdHENKImJWBcAAABteXNxbF9mZXRjaF9kYXRhKCRyZXMpO3EOigIVAXRxDyiJiVgXAAAAbXlzcWxfZmV0Y2hfbGlzdCgkcmVzKTtxEIoCFgF0cRFlRz/wAAAAAAAAigFKTnRxEihYLQAAAEpha2llIHRhZ2kgbW/FvG5hIHN0b3Nvd2HEhyB3ZXduxIV0cnogPGJvZHk+P3ETRz/wAAAAAAAAXXEUKCiIiFgIAAAAPHNjcmlwdD5xFYoBFnRxFiiJiVgGAAAAPG1ldGE+cReKARh0cRgoiIhYBQAAADxkaXY+cRmKARd0cRooiYlYBwAAADxzdHlsZT5xG4oBFXRxHGVHP/AAAAAAAACKAQZOdHEdKFhaAAAAT3R3YXJjaWUgb2tuYSBkaWFsb2dvd2VnbyB6IG5hcGlzZW0gIkFsZXJ0IHdpbmRvdyIgcmVhbGl6dWplIHNrxYJhZG5pYSBqxJl6eWthIEphdmFTY3JpcHQ/cR5HP/AAAAAAAABdcR8oKImJWB0AAAB3aW5kb3cuYWxlcnQoIkFsZXJ0IHdpbmRvdyIpO3EgigEtdHEhKImJWB8AAABkb2N1bWVudC5hbGVydCgiQWxlcnQgd2luZG93Iik7cSKKAS50cSMoiIhYGwAAAHNlbGYuYWxlcnQoIkFsZXJ0IHdpbmRvdyIpO3EkigEwdHElKIiIWBYAAABhbGVydCgiQWxlcnQgd2luZG93Iik7cSaKAS90cSdlRz/wAAAAAAAAigELTnRxKChYQQAAAEphayBtb8W8bmEgaW5mb3Jtb3dhxIcgcHJ6ZWdsxIVkYXJrxJkgbyBrb2Rvd2FuaXUgZG9rdW1lbnR1IEhUTUw/cSlHP/AAAAAAAABdcSooKIiIWBwAAABOYWfFgsOzd2VrIEhUVFAgQ29udGVudC1UeXBlcSuKAR10cSwoiYlYHgAAAERla2xhcmFjamEgPGh0bWwgZW5jb2Rpbmc9Ii4uLnEtigEgdHEuKImJWA0AAABCT00gZG9rdW1lbnR1cS+KAR90cTAoiIhYIwAAADxtZXRhIGh0dHAtZXF1aXY9IkNvbnRlbnQtVHlwZSIgLi4ucTGKAR50cTJlRz/wAAAAAAAAigEITnRxMyhYagAAAEt0w7NyYSBuYXp3YSB6bmFjem5pa2EgamVzdCB6Z29kbmEgemUgc2vFgmFkbmnEhSBqxJl6eWthIFhNTCBkbGEgcGxpa3UgYmV6IHpkZWZpbmlvd2FuZWogcHJ6ZXN0cnplbmkgbmF6dz9xNEc/8AAAAAAAAF1xNSgoiYlYGgAAADxuYXp3aXNrbyU+YWJjPC9uYXp3aXNrbyU+cTaKAT10cTcoiYlYGgAAADw1bmF6d2lza28+YWJjPC81bmF6d2lza28+cTiKAT90cTkoiIhYGgAAADxuYXp3aXNrby4+YWJjPC9uYXp3aXNrby4+cTqKAT50cTsoiYlYJAAAADxuYXp3aXNrbzpub3dhaz5hYmM8L25hendpc2tvOm5vd2FrPnE8igFAdHE9ZUc/8AAAAAAAAIoBE050cT4oWGwAAABKYWtpIHphcGlzIENTUyBzcG93b2R1amUgemF0cnp5bWFuaWUgb2JpZWt0w7N3IHDFgnl3YWrEhWN5Y2ggbGV3b3N0cm9ubmllIHBvd3nFvGVqIG9iaWVrdHkgeiB0eW3FvGUgemFwaXNlbT9xP0c/8AAAAAAAAF1xQCgoiIhYDAAAAGNsZWFyOiBib3RoO3FBigIDAXRxQiiIiFgMAAAAY2xlYXI6IGxlZnQ7cUOKAgQBdHFEKImJWA0AAABjbGVhcjogcmlnaHQ7cUWKAgUBdHFGKImJWAwAAABmbG9hdDogc3RvcDtxR4oCBgF0cUhlRz/wAAAAAAAAigFGTnRxSShYoAAAAFN0b3N1asSFYyBIVE1MIERPTSB6bWlhbsSZIHphd2FydG/Fm2NpIHRla3N0b3dlaiBwaWVyd3N6ZWoga29tw7Nya2kgdyBkcnVnaW0gd2llcnN6dSB0YWJlbGkgSFRNTCB6IGlkPSJteVRhYmxlIiBuYSBub3fEhSB3YXJ0b8WbxIcgbmV3VmFsdWUgdW1vxbxsaXdpYSBza8WCYWRuaWFxSkc/8AAAAAAAAF1xSygoiYlYRQAAAGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteVRhYmxlJykucm93c1sxXS5jZWxsc1swXS5zcmMgPSAibmV3VmFsdWUiO3FMigE1dHFNKIiIWEsAAABkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlUYWJsZScpLnJvd3NbMV0uY2VsbHNbMF0uaW5uZXJIVE1MID0gIm5ld1ZhbHVlIjtxTooBOHRxTyiJiVgwAAAAbXlUYWJsZS5yb3dzWzFdLmNlbGxzWzBdLmlubmVySFRNTCA9ICJuZXdWYWx1ZSI7cVCKATZ0cVEoiYlYKgAAAG15VGFibGUucm93c1sxXS5jZWxsc1swXS5zcmMgPSAibmV3VmFsdWUiO3FSigE3dHFTZUc/8AAAAAAAAIoBEE50cVQoWCQAAABLdMOzcnljaCB0YWfDs3cgTklFIGRlZmluaXVqZSBIVE1MNT9xVUc/8AAAAAAAAF1xVigoiYlYBAAAADxlbT5xV4oBDHRxWCiIiFgEAAAAPGg3PnFZigEKdHFaKImJWAYAAAA8bWV0YT5xW4oBCXRxXCiIiFgGAAAAPGZvbnQ+cV2KAQt0cV5lRz/wAAAAAAAAigEDTnRxXyhYZgAAAER5bmFtaWN6bsSFIHptaWFuxJkgd3lzb2tvxZtjaSBvYnJhemthIG8gaWRlbnR5ZmlrYXRvcnplIGlkPSJteUltZyIgemEgcG9tb2PEhSBIVE1MIERPTSByZWFsaXp1amUga29kOnFgRz/wAAAAAAAAXXFhKCiJiVg2AAAAZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ215SW1nJykuaGVpZ2h0ID0gIjMwMCI7cWKKATJ0cWMoiYlYMwAAAGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteUltZycpLmlubmVySFRNTCA9ICIzMDAiO3FkigExdHFlKIiIWDAAAABkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlJbWcnKS5oZWlnaHQgPSAiMzAwIjtxZooBM3RxZyiJiVgzAAAAZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ215SW1nJykuc3JjID0gIjMwMCI7cWiKATR0cWllRz/wAAAAAAAAigEPTnRxaihYLgAAAEpha2kgamVzdCB3eW5payBvcGVyYWNqaSAid2F0Ii0xIHcgSmF2YVNjcmlwdD9xa0c/8AAAAAAAAF1xbCgoiIhYAwAAAE5hTnFtigLfAHRxbiiJiVgEAAAAIndhInFvigLhAHRxcCiJiVgMAAAAcHVzdHkgc3RyaW5ncXGKAuAAdHFyKImJWAQAAABudWxscXOKAuIAdHF0ZUc/8AAAAAAAAIoBPE50cXUoWDsAAABXeWLDs3IgYmF6eSBkYW55Y2ggeiBwb3ppb211IGrEmXp5a2EgUEhQIHVtb8W8bGl3aWEgZnVua2NqYXF2Rz/wAAAAAAAAXXF3KCiJiVgvAAAAY29ubmVjdF9teXNxbCgpIHogcGFyYW1ldHJlbSBrbHVjem93eW0gZGF0YWJhc2VxeIoChAB0cXkoiYlYLwAAAG15c3FsX2Nvbm5lY3QoKSB6IHBhcmFtZXRyZW0ga2x1Y3pvd3ltIGRhdGFiYXNlcXqKAoUAdHF7KIiIWBEAAABteXNxbF9zZWxlY3RfZGIoKXF8igKDAHRxfSiJiVgRAAAAc2VsZWN0X215c3FsX2RiKClxfooCggB0cX9lRz/wAAAAAAAAigEkTnRxgChYWwAAAEpha2EgamVzdCBwb3ByYXduYSBza8WCYWRuaWEgb2R3b8WCYW5pYSB3IGRva3VtZW5jaWUgWEhUTUwgZG8gemV3bsSZdHJ6bmVnbyBhcmt1c3phIHN0eWzDs3dxgUc/8AAAAAAAAF1xgigoiYlYQQAAADxsaW5rIGhyZWY9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSJwbGlrX3N0eWxvdy5jc3MiIC8+cYOKAp0AdHGEKIiIWEAAAAA8bGluayByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSJwbGlrX3N0eWxvdy5jc3MiIC8+cYWKApoAdHGGKImJWEAAAAA8aGVhZCByZWw9InN0eWxlc2hlZXQiIHR5cGU9InRleHQvY3NzIiBocmVmPSJwbGlrX3N0eWxvdy5jc3MiIC8+cYeKApsAdHGIKImJWEEAAAA8c3R5bGUgcmVsPSJzdHlsZXNoZWV0IiB0eXBlPSJ0ZXh0L2NzcyIgaHJlZj0icGxpa19zdHlsb3cuY3NzIiAvPnGJigKcAHRximVHP/AAAAAAAACKASpOdHGLKFhcAAAAVyBqxJl6eWt1IFBIUCBmdW5rY2phIGZvcGVuKCJteUZpbGUudHh0IiwgImEiKSBwb3p3YWxhIG5hIG90d2FyY2llIHBsaWt1IG15RmlsZS50eHQgdyB0cnliaWVxjEc/8AAAAAAAAF1xjSgoiIhYGwAAAERvcGlzeXdhbmlhIGRhbnljaCBkbyBwbGlrdXGOigF9dHGPKImJWBQAAABEbyBjenl0YW5pYSBpIHphcGlzdXGQigF8dHGRKIiIWA8AAABUeWxrbyBkbyB6YXBpc3VxkooBe3RxkyiJiVgQAAAAVHlsa28gZG8gb2Rjenl0dXGUigF6dHGVZUc/8AAAAAAAAIoBIk50cZYoWFMAAABaYXBpcyBkbyBwbGlrdSBkcnpld2EgRE9NIHpkZWZpbmlvd2FuZWdvIHBvZCB6bWllbm7EhSAkZG9tIHcgasSZenlrdSBQSFAgdW1vxbxsaXdpYXGXRz/wAAAAAAAAXXGYKCiIiVgQAAAAJGRvbS0+c2F2ZVhNTCgpO3GZigKOAHRxmiiJiVgbAAAAJGRvbS0+b3BlbignZmlsZU5hbWUueG1sJyk7cZuKApAAdHGcKImJWC0AAABQSFAgbmllIHVtb8W8bGl3aWEgemFwaXN1IGRvIHBsaWt1IGRyemV3YSBET01xnYoCkQB0cZ4oiYhYGwAAACRkb20tPnNhdmUoJ2ZpbGVOYW1lLnhtbCcpO3GfigKPAHRxoGVLAIoBJ050caEoWCEAAABKYWtpIGplc3QgcG9wcmF3bnkgRE9DVFlQRSBIVE1MNT9xokc/8AAAAAAAAF1xoygoiIhYDwAAADwhRE9DVFlQRSBIVE1MPnGkigEBdHGlKIiIWA8AAAA8IWRvY3R5cGUgaHRtbD5xpooBAnRxpyiJiVhaAAAAPCFET0NUWVBFIEhUTUwgUFVCTElDICItLy9XNEMvL0RURCBIVE1MIDQuMDEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvVFIvaHRtbDQvc3RyaWN0LmR0ZCI+caiKAQN0cakoiYlYXAAAADwhRE9DVFlQRSBodG1sIFBVQkxJQyAiLS8vVzNDLy9EVEQgWEhUTUwgMi4wLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL01hcmtVcC9EVEQveGh0bWwyLmR0ZCI+caqKAQR0catlRz/wAAAAAAAAigEBTnRxrChYXQAAAFByb3N6xJkgemF6bmFjennEhyB6ZGFuaWEgcHJhd2R6aXdlIGRvdHljesSFY2UgcHJ6ZXR3YXJ6YW5pYSBkYW55Y2ggWE1MIHogcG96aW9tdSBqxJl6eWthIFBIUHGtRz/wAAAAAAAAXXGuKCiJiVhOAAAAJHhzbHQtPnRyYW5zZm9ybVRvRG9jKCR4bWwpIHBvendhbGEgbmEgcHJ6ZWtzenRhbGNlbmllIHBsaWt1IFhNTCBkbyBkcnpld2EgRE9Nca+KAogAdHGwKImJWDcAAABKxJl6eWsgUEhQIG5pZSBtYSBtZWNoYW5pem3Ds3cgcHJ6ZXR3YXJ6YW5pYSBkYW55Y2ggWE1McbGKAokAdHGyKImJWCcAAABJbnRlcmZlanMgU2ltcGxlWE1MIGplc3Qgc3RhbmRhcmRlbSBXM0Nxs4oChwB0cbQoiIhYQgAAAE5hend5IGZ1bmtjamkgb2JzxYJ1Z2kgemRhcnplxYQgdyBwYXJzZXJ6ZSBTQVggdHJ6ZWJhIHJlamVzdHJvd2HEh3G1igKGAHRxtmVHP/AAAAAAAACKASVOdHG3KFitAAAAVyB0ZWNobm9sb2dpaSBBSkFYIGRsYSB1c8WCdWdpIEdvb2dsZSBNYXBzIHR3b3J6ZW5pZSBvYmlla3R1IG1hcHkga2xhc3kgR01hcDIgaSB3c3Rhd2llbmllIGdvIGRvIGRpdi1hIHogaWRlbnR5ZmlrYXRvcmVtIG15TWFwIG9kYnl3YSBzacSZIHphIHBvbW9jxIUga29kdSBqxJl6eWthIEphdmFTY3JpcHRxuEc/8AAAAAAAAF1xuSgoiYlYKQAAAG1hcCA9IG5ldyBHTWFwMihnZXRFbGVtZW50QnlJZCgibXlNYXAiKSk7cbqKAWN0cbsoiYlYLQAAAG1hcCA9IG5ldyBHTWFwMihkaXYuZ2V0RWxlbWVudEJ5SWQoIm15TWFwIikpO3G8igFldHG9KImJWDAAAABtYXAgPSBuZXcgR01hcDIod2luZG93LmdldEVsZW1lbnRCeUlkKCJteU1hcCIpKTtxvooBZHRxvyiIiFgyAAAAbWFwID0gbmV3IEdNYXAyKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCJteU1hcCIpKTtxwIoBYnRxwWVHP/AAAAAAAACKARxOdHHCKFi1AAAAVyB6ZXduxJl0cnpuZWogZGVmaW5pY2ppIHR5cHUgZG9rdW1lbnR1IChEVEQpIGRvIGt0w7NyZWogb2R3b8WCdWplIHNpxJkgcGxpayBYTUwgdyBwaWVyd3N6ZWogbGluaWkgamVzdCB6YXBpcyA8IUVMRU1FTlQgYm9va3MgKGJvb2spKz4uIEt0w7NyZSBwb25pxbxzemUgc3R3aWVyZHplbmllIGplc3QgcHJhd2R6aXdlP3HDRz/wAAAAAAAAXXHEKCiJiFg0AAAARWxlbWVudCBnxYLDs3dueSB3IHBsaWt1IFhNTCBtdXNpIG5henl3YcSHIHNpxJkgYm9va3HFigFNdHHGKIiJWEAAAABFbGVtZW50IGfFgsOzd255IG8gbmF6d2llIGJvb2tzIG11c2kgbWllxIcgYXRyeWJ1dCBvIG5hendpZSBib29rcceKAU90ccgoiYlYLgAAAEF0cnlidXQgbyBuYXp3aWUgYm9vayBtdXNpIG1pZcSHIHdhcnRvxZvEhyAiKyJxyYoBUHRxyiiIiFhWAAAAWm5hY3puaWsgYm9va3MgbXVzaSB3eXN0xIVwacSHIHByenluYWptbmllaiBqZWRlbiByYXosIGFsZSBtb8W8ZSB3eXN0xIVwacSHIHdpZWxlIHJhenlxy4oBTnRxzGVLAIoBF050cc0oWF8AAABQYXJhIGVsZW1lbnTDs3cgPHhzbDpzdHlsZXNoZWV0IC4uLiI+IC4uLiA8L3hzbDpzdHlsZXNoZWV0PiB3IHBsaWt1IHN6YWJsb251ICoueHNsIGrEmXp5a2EgWFNMVHHORz/wAAAAAAAAXXHPKCiJiVgqAAAAVyBwcnplc3RyemVuaSB4c2wgbmllIG1hIHRha2llZ28gem5hY3puaWthcdCKAVN0cdEoiIhYQgAAAE9rcmXFm2xhIHJlZ3XFgnkgcHJ6ZWtzenRhxYJjYW5pYSB3xJl6xYJhIGfFgsOzd25lZ28gZG9rdW1lbnR1IFhNTHHSigFRdHHTKImJWEUAAABMaWN6YmEgd3lzdMSFcGllxYQgdGVnbyBlbGVtZW50dSB3IGRva3VtZW5jaWUgWFNMIGplc3Qgbmllb2dyYW5pY3pvbmFx1IoBVHRx1SiIiFhQAAAATW/FvGUgd3lzdMSFcGnEhyB3IGRva3VtZW5jaWUgWFNMIHR5bGtvIHJheiBwb25pZXdhxbwgZGVmaW5pdWplIGVsZW1lbnQgZ8WCw7N3bnlx1ooBUnRx12VHP/AAAAAAAACKARhOdHHYKFhBAAAAS3TDs3J5IHphcGlzIENTUyBqZXN0IHBvcHJhd255IHByenkgcG96eWNqb25vd2FuaXUgYmV6d3pnbMSZZG55bT9x2Uc/8AAAAAAAAF1x2igoiYlYNQAAAGgxLnBvc2l0aW9uX2xlZnQgeyBwb3NpdGlvbjogcmVsYXRpdmU7IGxlZnQ6IC01MHB4OyB9cduKAgIBdHHcKIiIWDQAAABoMS5wb3NpdGlvbl9sZWZ0IHsgcG9zaXRpb246IGFic29sdXRlOyBsZWZ0OiA1MHB4OyB9cd2KAv8AdHHeKIiIWDUAAABoMS5wb3NpdGlvbl9sZWZ0IHsgcG9zaXRpb246IGFic29sdXRlOyBsZWZ0OiAtNTBweDsgfXHfigIAAXRx4CiJiVg0AAAAaDEucG9zaXRpb25fbGVmdCB7IHBvc2l0aW9uOiByZWxhdGl2ZTsgbGVmdDogNTBweDsgfXHhigIBAXRx4mVHP/AAAAAAAACKAUVOdHHjKFhmAAAAVyBqYWtpbSBqxJl6eWt1IG1vxbxlIGJ5xIcgbmFwaXNhbnkga29kIGt0w7NyeSBwbyBzdHJvbmllIHNlcndlcmEgb2JzxYJ1Z2l3YcWCIGLEmWR6aWUgemFweXRhbmlhIEFKQVg/ceRHP/AAAAAAAABdceUoKIiIWAQAAABKYXZhceaKAicBdHHnKIiIWAMAAABQSFBx6IoCKQF0cekoiIhYCgAAAEphdmFTY3JpcHRx6ooCKgF0cesoiIhYAwAAAEMrK3HsigIoAXRx7WVHP/AAAAAAAACKAVFOdHHuKFgfAAAAS3RvIHVzdGFsYSBzdGFuZGFyZHkgc2llY2kgV2ViP3HvRz/wAAAAAAAAXXHwKCiJiVgGAAAAR29vZ2xlcfGKAu4AdHHyKIiIWAMAAABXM0Nx84oC7AB0cfQoiYlYBwAAAE1vemlsbGFx9YoC7QB0cfYoiIhYGQAAAFdvcmxkIFdpZGUgV2ViIENvbnNvcnRpdW1x94oC6wB0cfhlRz/wAAAAAAAAigFATnRx+ShYVAAAAFVzdGFsZW5pZSB3YXJ0b8WbY2kgYXRyeWJ1dHUgbyBuYXp3aWUgYXR0cl9uYW1lIHcgc3phYmxvbmFjaCBqxJl6eWthIFhTTFQgbWEgcG9zdGHEh3H6Rz/wAAAAAAAAXXH7KCiJiVgmAAAATmllIG1vxbxuYSB1c3RhbGHEhyB3YXJ0b8WbY2kgYXRyeWJ1dHVx/IoBXHRx/SiJiVg4AAAAPHhzbDp2YXJpYWJsZSBuYW1lPSJhdHRyX25hbWUiPmF0dHJfdmFsdWU8L3hzbDp2YXJpYWJsZT5x/ooBW3Rx/yiJiVgkAAAAPHhzbDp2YWx1ZS1vZiBzZWxlY3Q9IkBhdHRyX25hbWUiIC8+cgABAACKAVp0cgEBAAAoiIhYOgAAADx4c2w6YXR0cmlidXRlIG5hbWU9ImF0dHJfbmFtZSI+YXR0cl92YWx1ZTwveHNsOmF0dHJpYnV0ZT5yAgEAAIoBWXRyAwEAAGVHP/AAAAAAAACKARpOdHIEAQAAKFiZAAAAT2RzecWCYWN6IGhpcGVydGVrc3Rvd3kgeiBtaWVqc2NhICJUZWtzdCBvZHN5xYJhY3phIiBkbyBtaWVqc2NhICJNaWVqc2NlIG9kZXPFgmFuaWEiIHcgcmFtYWNoIHRlaiBzYW1laiBzdHJvbnkgSFRNTCBqZXN0IHJlYWxpem93YW55IHphIHBvbW9jxIUgc2vFgmFkbmk/cgUBAABHP/AAAAAAAABdcgYBAAAoKIiIWEcAAAA8YSBocmVmPSIjbXlJRCI+VGVrc3Qgb2RzecWCYWN6YTwvYT48YSBpZD0ibXlJRCI+TWllanNjZSBvZGVzxYJhbmlhPC9hPnIHAQAAigErdHIIAQAAKImJWEgAAAA8YSBocmVmPSIjbXlJRCI+VGVrc3Qgb2RzecWCYWN6YTwvYT48YSBpZD0iI215SUQiPk1pZWpzY2Ugb2Rlc8WCYW5pYTwvYT5yCQEAAIoBKnRyCgEAACiJiVhGAAAAPGEgaHJlZj0ibXlJRCI+VGVrc3Qgb2RzecWCYWN6YTwvYT48YSBpZD0ibXlJRCI+TWllanNjZSBvZGVzxYJhbmlhPC9hPnILAQAAigEsdHIMAQAAKImJWEcAAAA8YSBocmVmPSJteUlEIj5UZWtzdCBvZHN5xYJhY3phPC9hPjxhIGlkPSIjbXlJRCI+TWllanNjZSBvZGVzxYJhbmlhPC9hPnINAQAAigEpdHIOAQAAZUc/8AAAAAAAAIoBDU50cg8BAAAoWDEAAABKYWtpIHJvZHphaiBkYW55Y2ggb2RiaWVyYcSHIG1vxbxuYSBwb3ByemV6IEFKQVg/chABAABHP/AAAAAAAABdchEBAAAoKIiIWAQAAABZQU1MchIBAACKAiYBdHITAQAAKIiIWAQAAABKU09OchQBAACKAiUBdHIVAQAAKIiIWAQAAABIVE1MchYBAACKAiMBdHIXAQAAKIiIWAMAAABYTUxyGAEAAIoCJAF0chkBAABlRz/wAAAAAAAAigFQTnRyGgEAAChYiQAAAEt0w7NyYSBzdHJ1a3R1cmEgdWFrdHVhbG5pZW5pYSBkaXYtYSBzdHJvbnkgSFRNTCBvIGlkPSJteURpdiIgcHJ6eSDFvMSFZGFuaXUgQUpBWCBkbGEgb2Rwb3dpZWR6aSBYTUwgamVzdCBtb8W8bGl3YSBwb2Qgd3pnbMSZZGVtIHNrxYJhZG5pchsBAABHP/AAAAAAAABdchwBAAAoKIiIWBUAAAByZXF1ZXN0LnJlc3BvbnNlVGV4dDtyHQEAAIoBbnRyHgEAACiIiFg5AAAAcmVxdWVzdC5yZXNwb25zZVhNTC5kb2N1bWVudEVsZW1lbnQuZmlyc3RDaGlsZC5ub2RlVmFsdWU7ch8BAACKAW90ciABAAAoiYlYOwAAAGRvY3VtZW50LnJlc3BvbnNlVGV4dC5kb2N1bWVudEVsZW1lbnQuZmlyc3RDaGlsZC5ub2RlVmFsdWU7ciEBAACKAXB0ciIBAAAoiYlYFQAAAGRvY3VtZW50LnJlc3BvbnNlWE1MO3IjAQAAigFxdHIkAQAAZUc/8AAAAAAAAIoBH050ciUBAAAoWEwAAABXIGrEmXp5a3UgWE1MIG9rcmXFm2xlbmllIHpuYWN6bmlrYSBteVRhZyB6IHByemVzdHJ6ZW5pIG5hencgbXlOcyBtYSBwb3N0YcSHciYBAABHP/AAAAAAAABdcicBAAAoKImJWCYAAAA8eG1sbnM6bXlUYWc+WmF3YXJ0b8WbxIc8L3htbG5zOm15VGFnPnIoAQAAigFDdHIpAQAAKImJWCQAAAA8bXlUYWc6bXlOcz5aYXdhcnRvxZvEhzwvbXlUYWc6bXlOcz5yKgEAAIoBQXRyKwEAACiIiFgkAAAAPG15TnM6bXlUYWc+WmF3YXJ0b8WbxIc8L215TnM6bXlUYWc+ciwBAACKAUJ0ci0BAAAoiYlYJAAAADxteU5zOnhtbG5zPlphd2FydG/Fm8SHPC9teU5zOnhtbG5zPnIuAQAAigFEdHIvAQAAZUc/8AAAAAAAAIoBFE50cjABAAAoWJ8AAABQcnpla2F6YW5pZSBuYXp3eSBmdW5rY2ppIGt0w7NyYSBixJlkemllIHd5d2/Fgnl3YW5hIGtpZWR5IHBhcnNlciBTQVggY3p5dGEgZGFuZSB6bmFrb3dlIHVtaWVzemN6b25lIG1pxJlkenkgcGFyxIUgem5hY3puaWvDs3cgdW1vxbxsaXdpYSB3YnVkb3dhbmEgZnVua2NqYSBQSFByMQEAAEc/8AAAAAAAAF1yMgEAACgoiYlYEwAAAHhtbF9wYXJzZXJfY3JlYXRlKClyMwEAAIoCigB0cjQBAAAoiIhYIAAAAHhtbF9zZXRfY2hhcmFjdGVyX2RhdGFfaGFuZGxlcigpcjUBAACKAowAdHI2AQAAKImJWBkAAAB4bWxfc2V0X2VsZW1lbnRfaGFuZGxlcigpcjcBAACKAosAdHI4AQAAKImJWAsAAAB4bWxfcGFyc2UoKXI5AQAAigKNAHRyOgEAAGVHP/AAAAAAAACKASZOdHI7AQAAKFihAAAAVyB0ZWNobm9sb2dpaSBBSkFYIHByenkgcmVhbGl6YWNqaSDFvMSFZGFuaWEgdHlwdSBHRVQgZG9kYWplIHNpxJkgZG8ga2/FhGNhIGFkcmVzdSBVUkwgZG9kYXRrb3d5LCBuaWMgbmllIHpuYWN6xIVjeSBwYXJhbWV0ciB6IGxvc293xIUgd2FydG/Fm2NpxIUuIFcgamFraW0gY2VsdT9yPAEAAEc/8AAAAAAAAF1yPQEAACgoiYlYLwAAAEFieSB6d2nEmWtzennEhyBzenlia2/Fm8SHIHJlYWxpemFjamkgxbzEhWRhbmlhcj4BAACKAXJ0cj8BAAAoiIhYSgAAAEFieSBzdHJvbmEgbmllIGJ5xYJhIHdjenl0YW5hIHogcGFtacSZY2kgcG9kcsSZY3puZWogcHJ6ZWdsxIVkYXJraSAoY2FjaGUpckABAACKAXR0ckEBAAAoiIhYOwAAAEFieSB6YSBrYcW8ZHltIHJhemVtIGJ5xYJvIHd5Z2VuZXJvd2FuZSBub3dlIMW8xIVkYW5pZSBIVFRQckIBAACKAXN0ckMBAAAoiYlYLgAAAFcgb2fDs2xlIG5pZSBzdG9zdWplIHNpxJkgdGFraWVnbyByb3p3acSFemFuaWFyRAEAAIoBdXRyRQEAAGVHP/AAAAAAAACKASBOdHJGAQAAKFgxAAAASmFrIG9kd2/FgnVqZW15IHNpxJkgZG8gemV3bsSZdHJ6bmVnbyBKYXZhU2NyaXB0P3JHAQAARz/wAAAAAAAAXXJIAQAAKCiJiVg8AAAAPHNjcmlwdCBsYW5ndWFnZT0iamF2YXNjcmlwdCIgaHJlZj0iamF2YXNjcmlwdC5qcyI+PC9zY3JpcHQ+ckkBAACKAsgAdHJKAQAAKIiIWDsAAAA8c2NyaXB0IGxhbmd1YWdlPSJqYXZhc2NyaXB0IiBzcmM9ImphdmFzY3JpcHQuanMiPjwvc2NyaXB0PnJLAQAAigLHAHRyTAEAACiIiFg8AAAAPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiIHNyYz0iamF2YXNjcmlwdC5qcyI+PC9zY3JpcHQ+ck0BAACKAskAdHJOAQAAKImJWD0AAAA8c2NyaXB0IHR5cGU9InRleHQvamF2YXNjcmlwdCIgaHJlZj0iamF2YXNjcmlwdC5qcyI+PC9zY3JpcHQ+ck8BAACKAsoAdHJQAQAAZUc/8AAAAAAAAIoBNk50clEBAABldS4=');

-- --------------------------------------------------------

--
-- Table structure for table `users_user`
--

CREATE TABLE IF NOT EXISTS `users_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `surname` longtext COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `number` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_user_26440ee6` (`login`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=48 ;

--
-- Dumping data for table `users_user`
--

INSERT INTO `users_user` (`id`, `name`, `surname`, `login`, `password`, `status`, `number`, `created_on`) VALUES
(1, 'Domyślny', 'administrator', 'root@example.com', 'ff8cd71659c3740537b19551d0d8eb2d7da099b5', 2, 0, '0000-00-00 00:00:00'),
(2, 'Domyślny', 'nauczyciel', 'teacher@demo.athena', '098ea47eaf7e33dc05820f65141cc3a2aca8d426', 1, 0, '0000-00-00 00:00:00'),
(3, 'Test', 'Nauczyciel', 'teacher@example.com', '306a04d6d892255921f2325c69c5e87506d16f46', 1, NULL, '2014-01-29 01:11:57'),
(4, 'Adrian', 'Siekierka', 'kontakt@asie.pl', '9973963f63ee1bf1ffb96c8e8e5e09f06aa86bbe', 0, 0, '0000-00-00 00:00:00'),
(8, 'Piotr', 'Maślanka', 'piotr.maslanka@henrietta.com.pl', 'c8f64637a30d73151f20e95a09af87ee1bdb6fcc', 0, 127172, '2014-01-24 14:22:04'),
(14, 'Tymczasowe konto DEMO', '', '4229173@demo.athena', '', 0, 0, '2014-01-24 22:55:25'),
(15, 'Tymczasowe konto DEMO', '', '5581693@demo.athena', '', 0, 0, '2014-01-25 08:34:28'),
(18, 'Tymczasowe konto DEMO', '', '511110@demo.athena', '', 0, 0, '2014-01-27 12:14:54'),
(20, 'Mateusz', 'Salach', 'matyo35@mailinator.com', '26ecee366aa37a4ecd29eb4cccf5968aab013b1a', 0, 127246, '2014-01-28 12:25:13'),
(21, 'Tymczasowe konto DEMO', '', '983791@demo.athena', '', 0, 0, '2014-01-28 14:28:41'),
(25, 'Tymczasowe konto DEMO', '', '1929470@demo.athena', '', 0, 0, '2014-01-28 22:59:19'),
(26, 'Tymczasowe konto DEMO', '', '6411195@demo.athena', '', 0, 0, '2014-01-28 22:59:19'),
(27, 'Tymczasowe konto DEMO', '', '6673491@demo.athena', '', 0, 0, '2014-01-28 23:31:30'),
(30, 'Tymczasowe konto DEMO', '', '4420840@demo.athena', '', 0, 0, '2014-01-29 00:03:42'),
(36, 'Tymczasowe konto DEMO', '', '6508962@demo.athena', '', 0, 0, '2014-01-29 09:28:18'),
(39, 'Tymczasowe konto DEMO', '', '2306139@demo.athena', '', 0, 0, '2014-01-29 11:24:47'),
(40, 'Tymczasowe konto DEMO', '', '6129739@demo.athena', '', 0, 0, '2014-01-29 11:26:03'),
(43, 'Tymczasowe konto DEMO', '', '7339618@demo.athena', '', 0, 0, '2014-01-29 12:25:34'),
(46, 'Tymczasowe konto DEMO', '', '1717224@demo.athena', '', 0, 0, '2014-01-30 02:31:46'),
(47, 'Tymczasowe konto DEMO', '', '7876580@demo.athena', '', 0, 0, '2014-01-30 10:50:03');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rteacher_exam`
--
ALTER TABLE `rteacher_exam`
  ADD CONSTRAINT `test_id_refs_id_fa64c143` FOREIGN KEY (`test_id`) REFERENCES `tests_test` (`id`),
  ADD CONSTRAINT `group_id_refs_id_bcfe28a6` FOREIGN KEY (`group_id`) REFERENCES `rteacher_group` (`id`),
  ADD CONSTRAINT `owner_id_refs_id_d16335ed` FOREIGN KEY (`owner_id`) REFERENCES `users_user` (`id`);

--
-- Constraints for table `rteacher_group`
--
ALTER TABLE `rteacher_group`
  ADD CONSTRAINT `teacher_id_refs_id_091359f8` FOREIGN KEY (`teacher_id`) REFERENCES `users_user` (`id`);

--
-- Constraints for table `rteacher_group_students`
--
ALTER TABLE `rteacher_group_students`
  ADD CONSTRAINT `group_id_refs_id_da5e05f4` FOREIGN KEY (`group_id`) REFERENCES `rteacher_group` (`id`),
  ADD CONSTRAINT `user_id_refs_id_f38f6ef7` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`);

--
-- Constraints for table `rteacher_joinrequest`
--
ALTER TABLE `rteacher_joinrequest`
  ADD CONSTRAINT `student_id_refs_id_8184414a` FOREIGN KEY (`student_id`) REFERENCES `users_user` (`id`),
  ADD CONSTRAINT `group_id_refs_id_a37f2104` FOREIGN KEY (`group_id`) REFERENCES `rteacher_group` (`id`);

--
-- Constraints for table `rteacher_term`
--
ALTER TABLE `rteacher_term`
  ADD CONSTRAINT `exam_id_refs_id_edfcd4e0` FOREIGN KEY (`exam_id`) REFERENCES `rteacher_exam` (`id`);

--
-- Constraints for table `tests_answer`
--
ALTER TABLE `tests_answer`
  ADD CONSTRAINT `question_id_refs_id_cda43606` FOREIGN KEY (`question_id`) REFERENCES `tests_question` (`id`);

--
-- Constraints for table `tests_attachment`
--
ALTER TABLE `tests_attachment`
  ADD CONSTRAINT `question_id_refs_id_5ac8e045` FOREIGN KEY (`question_id`) REFERENCES `tests_question` (`id`);

--
-- Constraints for table `tests_category`
--
ALTER TABLE `tests_category`
  ADD CONSTRAINT `test_id_refs_id_9eb0b26c` FOREIGN KEY (`test_id`) REFERENCES `tests_test` (`id`);

--
-- Constraints for table `tests_question`
--
ALTER TABLE `tests_question`
  ADD CONSTRAINT `category_id_refs_id_4451993d` FOREIGN KEY (`category_id`) REFERENCES `tests_category` (`id`);

--
-- Constraints for table `tests_test`
--
ALTER TABLE `tests_test`
  ADD CONSTRAINT `owner_id_refs_id_328ccb25` FOREIGN KEY (`owner_id`) REFERENCES `users_user` (`id`);

--
-- Constraints for table `tests_testbeingwritten`
--
ALTER TABLE `tests_testbeingwritten`
  ADD CONSTRAINT `term_id_refs_id_e1eed91f` FOREIGN KEY (`term_id`) REFERENCES `rteacher_term` (`id`),
  ADD CONSTRAINT `written_by_id_refs_id_2d0409e7` FOREIGN KEY (`written_by_id`) REFERENCES `users_user` (`id`);

--
-- Constraints for table `tests_testresult`
--
ALTER TABLE `tests_testresult`
  ADD CONSTRAINT `term_id_refs_id_c5070e7a` FOREIGN KEY (`term_id`) REFERENCES `rteacher_term` (`id`),
  ADD CONSTRAINT `written_by_id_refs_id_f43a1f44` FOREIGN KEY (`written_by_id`) REFERENCES `users_user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
